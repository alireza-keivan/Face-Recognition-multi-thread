/**
 * Face Recognition Web Admin - JavaScript
 * Simple and Clean
 */

// ========== Global Variables ==========
const API_BASE = '';

// ========== Utility Functions ==========

/**
 * Show loading overlay
 */
function showLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.add('active');
    }
}

/**
 * Hide loading overlay
 */
function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.classList.remove('active');
    }
}

/**
 * Show toast notification
 */
function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toastContainer');
    if (!toastContainer) return;

    const toast = document.createElement('div');
    toast.className = `alert alert-${type} alert-dismissible fade show`;
    toast.innerHTML = `
        ${message}
        <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
    `;
    
    toastContainer.appendChild(toast);
    
    // Auto remove after 5 seconds
    setTimeout(() => {
        toast.remove();
    }, 5000);
}

/**
 * Confirm dialog
 */
function confirmAction(message) {
    return confirm(message);
}

// ========== Face Management ==========

/**
 * Delete a person (all their images)
 */
function deletePerson(name) {
    if (!confirmAction(`آیا از حذف "${name}" و تمام تصاویر مطمئن هستید؟`)) {
        return;
    }

    showLoading();
    
    fetch(`/faces/delete/${encodeURIComponent(name)}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showToast(data.message, 'success');
            // Remove card from DOM
            const card = document.querySelector(`[data-person="${name}"]`);
            if (card) {
                card.remove();
            }
            // Reload after short delay
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.message || 'خطا در حذف', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        showToast('خطا در ارتباط با سرور', 'danger');
        console.error('Error:', error);
    });
}

/**
 * Delete single image
 */
function deleteImage(name, filename) {
    if (!confirmAction(`آیا از حذف این تصویر مطمئن هستید؟`)) {
        return;
    }

    showLoading();
    
    fetch(`/faces/delete-image/${encodeURIComponent(name)}/${encodeURIComponent(filename)}`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showToast(data.message, 'success');
            setTimeout(() => location.reload(), 1000);
        } else {
            showToast(data.message || 'خطا در حذف تصویر', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        showToast('خطا در ارتباط با سرور', 'danger');
        console.error('Error:', error);
    });
}

/**
 * Preview image in modal
 */
function previewImage(src, title) {
    const modal = document.getElementById('imagePreviewModal');
    if (!modal) return;
    
    const modalImg = modal.querySelector('#previewImage');
    const modalTitle = modal.querySelector('.modal-title');
    
    if (modalImg) modalImg.src = src;
    if (modalTitle) modalTitle.textContent = title || 'پیش‌نمایش';
    
    const bsModal = new bootstrap.Modal(modal);
    bsModal.show();
}

// ========== File Upload ==========

/**
 * Initialize file upload area with drag & drop
 */
function initFileUpload() {
    const uploadArea = document.querySelector('.file-upload-area');
    const fileInput = document.getElementById('faceImages');
    
    if (!uploadArea || !fileInput) return;

    // Click to upload
    uploadArea.addEventListener('click', () => {
        fileInput.click();
    });

    // Drag events
    uploadArea.addEventListener('dragover', (e) => {
        e.preventDefault();
        uploadArea.classList.add('dragover');
    });

    uploadArea.addEventListener('dragleave', () => {
        uploadArea.classList.remove('dragover');
    });

    uploadArea.addEventListener('drop', (e) => {
        e.preventDefault();
        uploadArea.classList.remove('dragover');
        
        const files = e.dataTransfer.files;
        if (files.length > 0) {
            fileInput.files = files;
            updateFileList(files);
        }
    });

    // File input change
    fileInput.addEventListener('change', (e) => {
        updateFileList(e.target.files);
    });
}

/**
 * Update file list display
 */
function updateFileList(files) {
    const listContainer = document.getElementById('fileList');
    if (!listContainer) return;
    
    listContainer.innerHTML = '';
    
    if (files.length === 0) return;
    
    const list = document.createElement('ul');
    list.className = 'list-group mt-2';
    
    Array.from(files).forEach(file => {
        const item = document.createElement('li');
        item.className = 'list-group-item d-flex justify-content-between align-items-center';
        item.innerHTML = `
            <span><i class="bi bi-image me-2"></i>${file.name}</span>
            <span class="badge bg-secondary">${formatFileSize(file.size)}</span>
        `;
        list.appendChild(item);
    });
    
    listContainer.appendChild(list);
}

/**
 * Format file size
 */
function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
}

// ========== Settings ==========

/**
 * Restart face recognition service
 */
function restartService() {
    if (!confirmAction('آیا از ری‌استارت سرویس تشخیص چهره مطمئن هستید؟')) {
        return;
    }

    showLoading();
    
    fetch('/settings/restart-service', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        hideLoading();
        if (data.success) {
            showToast('سرویس با موفقیت ری‌استارت شد', 'success');
        } else {
            showToast(data.message || 'خطا در ری‌استارت', 'danger');
        }
    })
    .catch(error => {
        hideLoading();
        showToast('خطا در ارتباط با سرور', 'danger');
        console.error('Error:', error);
    });
}

// ========== Dashboard ==========

/**
 * Refresh dashboard stats
 */
/**
 * Refresh dashboard stats
 */
function refreshStats() {
    fetch('/api/stats')
        .then(response => response.json())
        .then(data => {
            if (!data.success) return;

            // Update stat cards
            document.getElementById('statTotalLogs').textContent = data.data.total_logs;
            document.getElementById('statKnownCount').textContent = data.data.known_count;
            document.getElementById('statUnknownCount').textContent = data.data.unknown_count;

            // Activity chart (optional)
            if (window.activityChart && data.data.chart_labels) {
                window.activityChart.data.labels = data.data.chart_labels;
                window.activityChart.data.datasets[0].data = data.data.chart_values;
                window.activityChart.update();
            }
        })
        .catch(err => console.error('Error loading stats:', err));
}

/**
 * Load recognition logs with pagination
 */
function loadLogs(page = 1) {
    const logsContainer = document.getElementById('logsTableBody');
    const paginationContainer = document.getElementById('logsPagination');

    if (!logsContainer || !paginationContainer) return;

    fetch(`/api/logs?page=${page}`)
        .then(response => response.json())
        .then(data => {
            if (!data.success) return;

            const logs = data.data.items;
            logsContainer.innerHTML = '';

            if (logs.length === 0) {
                logsContainer.innerHTML = `
                    <tr>
                        <td colspan="7" class="text-center text-muted py-3">
                            هیچ رکوردی یافت نشد
                        </td>
                    </tr>`;
                return;
            }

            logs.forEach(log => {
                const knownBadge = log.identity_verified
                    ? '<span class="badge badge-known">تأیید شده</span>'
                    : '<span class="badge badge-unknown">ناشناس</span>';

                logsContainer.innerHTML += `
                    <tr>
                        <td>${log.timestamp}</td>
                        <td>${log.recognized_person || '-'}</td>
                        <td>${knownBadge}</td>
                        <td>${parseFloat(log.cosine_similarity).toFixed(3)}</td>
                        <td>${log.door_num}</td>
                        <td>${log.face_coordinates}</td>
                        <td>${log.operation_region}</td>
                    </tr>
                `;
            });

            // Pagination
            paginationContainer.innerHTML = '';
            for (let p = 1; p <= data.data.total_pages; p++) {
                paginationContainer.innerHTML += `
                    <li class="page-item ${p === data.data.page ? 'active' : ''}">
                        <button class="page-link" onclick="loadLogs(${p})">${p}</button>
                    </li>
                `;
            }
        })
        .catch(error => console.error('Error loading logs:', error));
}

/**
 * Auto-initialize dashboard components
 */
document.addEventListener('DOMContentLoaded', () => {
    // For dashboard
    if (document.getElementById('statTotalLogs')) {
        refreshStats();
        setInterval(refreshStats, 5000);
    }

    // For logs
    if (document.getElementById('logsTableBody')) {
        loadLogs();
    }

    // For face upload page
    if (document.querySelector('.file-upload-area')) {
        initFileUpload();
    }
});
