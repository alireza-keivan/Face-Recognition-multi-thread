# User Authentication System - Setup Complete

## Overview
A complete user authentication system has been added to your Face Recognition webapp running on `192.168.45.235:5000`.

## Features Added

### 1. User Registration
- Users can register with username, email (optional), and password
- Password must be at least 6 characters
- Username must be at least 3 characters and unique
- Located at: `http://192.168.45.235:5000/register`

### 2. User Login
- Users can login with their username and password
- Session management with Flask-Login
- Automatic redirect to dashboard after successful login
- Located at: `http://192.168.45.235:5000/login`

### 3. Protected Routes
All main routes now require authentication:
- Dashboard (`/`)
- Face management (`/persons`, `/faces`)
- Settings (`/settings`)
- Logs (`/logs`)
- Cameras (`/cameras`)
- And all related actions (add, delete, etc.)

### 4. User Interface
- Persian (Farsi) language interface
- User info displayed in navigation bar
- Logout button in navigation
- Flash messages for user feedback

## Default Admin Account

An admin account has been created for you:
- **Username:** `admin`
- **Password:** `admin123`

⚠️ **IMPORTANT:** Change this password immediately after first login!

## Database

A new `users` table has been created in your PostgreSQL database with:
- `id` - Primary key
- `username` - Unique username (indexed)
- `email` - Optional email (unique if provided)
- `password_hash` - Securely hashed password
- `created_at` - Account creation timestamp
- `last_login` - Last login timestamp
- `is_active` - Account status (active/inactive)

## How to Use

### Starting the Webapp

```bash
cd /home/face/Face-Recognition-multi-thread
source bin/activate
cd webapp
python app.py
```

Or if you have it set up as a service:
```bash
sudo systemctl restart face-recognition-webapp
```

### First Time Setup

1. Navigate to: `http://192.168.45.235:5000`
2. You'll be redirected to the login page
3. Login with the admin account:
   - Username: `admin`
   - Password: `admin123`
4. Once logged in, go to register page to create additional users
5. **Change the admin password immediately!**

### Creating New Users

1. Visit: `http://192.168.45.235:5000/register`
2. Fill in:
   - Username (required, min 3 chars)
   - Email (optional)
   - Password (required, min 6 chars)
   - Confirm Password
3. Click "ثبت نام" (Register)
4. After successful registration, you'll be redirected to login

### Logging Out

Click the "خروج" (Logout) button in the top navigation bar.

## Security Features

1. **Password Hashing**: All passwords are hashed using Werkzeug's secure password hashing (PBKDF2)
2. **Session Management**: Flask-Login manages user sessions securely
3. **Protected Routes**: All main pages require authentication via `@login_required` decorator
4. **Input Validation**: 
   - Minimum password length (6 chars)
   - Minimum username length (3 chars)
   - Unique username and email
   - Password confirmation match

## Files Modified/Created

### Modified Files:
1. `/webapp/requirements.txt` - Added Flask-Login and jdatetime
2. `/webapp/database.py` - Added User model with authentication methods
3. `/webapp/app.py` - Added authentication routes and login_required decorators
4. `/webapp/templates/base.html` - Added user info and logout button

### New Files:
1. `/webapp/templates/login.html` - Login page
2. `/webapp/templates/register.html` - Registration page
3. `/webapp/init_auth.py` - Database initialization script

## Troubleshooting

### Can't access any pages
- Make sure you're logged in
- Try going to `/login` directly
- Clear browser cookies and try again

### Forgot password
Run this script to reset a user's password:
```bash
cd /home/face/Face-Recognition-multi-thread
source bin/activate
python -c "
from webapp.database import db_manager, User
session = db_manager.get_session()
user = session.query(User).filter_by(username='admin').first()
if user:
    user.set_password('newpassword123')
    session.commit()
    print('Password reset successfully!')
session.close()
"
```

### Need to create additional admin users
You can modify the `init_auth.py` script or create users via the register page, then manually set their admin status in the database if needed.

## Next Steps

1. Login with the admin account
2. Create your personal user account
3. Consider deactivating or deleting the default admin account
4. Test all features to ensure everything works
5. Set up proper backup procedures for the users table

## Support

If you encounter any issues:
1. Check the Flask app logs
2. Check the PostgreSQL database connection
3. Ensure all dependencies are installed (`pip install -r requirements.txt`)
4. Verify the database `users` table exists

---
*Face Recognition System - User Authentication*
*Setup completed on: December 30, 2025*
