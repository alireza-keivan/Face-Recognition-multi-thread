#!/usr/bin/env python3
"""
database_service.py - Database operations service
"""

from datetime import datetime, timedelta
from typing import Optional, List, Dict, Any, Tuple
from sqlalchemy import func, desc, and_, or_, extract
from ..models import db, RecognitionLog, ConfigSnapshot


class DatabaseService:
    """Service class for database operations"""
    
    @staticmethod
    def get_recognition_logs(
        page: int = 1,
        per_page: int = 20,
        person_name: Optional[str] = None,
        verified_only: Optional[bool] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        door_num: Optional[int] = None,
        sort_by: str = 'timestamp',
        sort_order: str = 'desc'
    ) -> Tuple[List[RecognitionLog], int]:
        """
        Get recognition logs with filtering and pagination
        
        Returns:
            Tuple of (logs list, total count)
        """
        query = RecognitionLog.query
        
        # Apply filters
        if person_name:
            query = query.filter(
                RecognitionLog.recognized_person.ilike(f'%{person_name}%')
            )
        
        if verified_only is not None:
            query = query.filter(RecognitionLog.identity_verified == verified_only)
        
        if start_date:
            query = query.filter(RecognitionLog.timestamp >= start_date)
        
        if end_date:
            query = query.filter(RecognitionLog.timestamp <= end_date)
        
        if door_num is not None:
            query = query.filter(RecognitionLog.door_num == door_num)
        
        # Get total count before pagination
        total = query.count()
        
        # Apply sorting
        sort_column = getattr(RecognitionLog, sort_by, RecognitionLog.timestamp)
        if sort_order == 'desc':
            query = query.order_by(desc(sort_column))
        else:
            query = query.order_by(sort_column)
        
        # Apply pagination
        logs = query.offset((page - 1) * per_page).limit(per_page).all()
        
        return logs, total
    
    @staticmethod
    def get_log_by_id(log_id: int) -> Optional[RecognitionLog]:
        """Get single recognition log by ID"""
        return RecognitionLog.query.get(log_id)
    
    @staticmethod
    def delete_log(log_id: int) -> bool:
        """Delete a recognition log by ID"""
        log = RecognitionLog.query.get(log_id)
        if log:
            db.session.delete(log)
            db.session.commit()
            return True
        return False
    
    @staticmethod
    def delete_logs_bulk(log_ids: List[int]) -> int:
        """Delete multiple logs by IDs, returns count of deleted"""
        deleted = RecognitionLog.query.filter(
            RecognitionLog.id.in_(log_ids)
        ).delete(synchronize_session=False)
        db.session.commit()
        return deleted
    
    @staticmethod
    def get_dashboard_stats() -> Dict[str, Any]:
        """Get statistics for dashboard"""
        now = datetime.utcnow()
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
        week_ago = now - timedelta(days=7)
        month_ago = now - timedelta(days=30)
        
        # Total counts
        total_logs = RecognitionLog.query.count()
        verified_total = RecognitionLog.query.filter(
            RecognitionLog.identity_verified == True
        ).count()
        unverified_total = RecognitionLog.query.filter(
            RecognitionLog.identity_verified == False
        ).count()
        
        # Today's counts
        today_logs = RecognitionLog.query.filter(
            RecognitionLog.timestamp >= today_start
        ).count()
        today_verified = RecognitionLog.query.filter(
            and_(
                RecognitionLog.timestamp >= today_start,
                RecognitionLog.identity_verified == True
            )
        ).count()
        
        # This week's counts
        week_logs = RecognitionLog.query.filter(
            RecognitionLog.timestamp >= week_ago
        ).count()
        week_verified = RecognitionLog.query.filter(
            and_(
                RecognitionLog.timestamp >= week_ago,
                RecognitionLog.identity_verified == True
            )
        ).count()
        
        # This month's counts
        month_logs = RecognitionLog.query.filter(
            RecognitionLog.timestamp >= month_ago
        ).count()
        
        # Unique persons count
        unique_persons = db.session.query(
            func.count(func.distinct(RecognitionLog.recognized_person))
        ).filter(
            RecognitionLog.identity_verified == True
        ).scalar() or 0
        
        # Average similarity for verified faces
        avg_similarity = db.session.query(
            func.avg(RecognitionLog.cosine_similarity)
        ).filter(
            RecognitionLog.identity_verified == True
        ).scalar() or 0
        
        # Recent activity (last 10 logs)
        recent_logs = RecognitionLog.query.order_by(
            desc(RecognitionLog.timestamp)
        ).limit(10).all()
        
        # Hourly distribution for today
        hourly_stats = db.session.query(
            extract('hour', RecognitionLog.timestamp).label('hour'),
            func.count(RecognitionLog.id).label('count')
        ).filter(
            RecognitionLog.timestamp >= today_start
        ).group_by(
            extract('hour', RecognitionLog.timestamp)
        ).all()
        
        hourly_data = {int(h): c for h, c in hourly_stats}
        
        # Top recognized persons (last 7 days)
        top_persons = db.session.query(
            RecognitionLog.recognized_person,
            func.count(RecognitionLog.id).label('count')
        ).filter(
            and_(
                RecognitionLog.timestamp >= week_ago,
                RecognitionLog.identity_verified == True
            )
        ).group_by(
            RecognitionLog.recognized_person
        ).order_by(
            desc('count')
        ).limit(10).all()
        
        # Door statistics
        door_stats = db.session.query(
            RecognitionLog.door_num,
            func.count(RecognitionLog.id).label('count')
        ).filter(
            RecognitionLog.door_num.isnot(None)
        ).group_by(
            RecognitionLog.door_num
        ).all()
        
        return {
            'total': {
                'logs': total_logs,
                'verified': verified_total,
                'unverified': unverified_total,
                'unique_persons': unique_persons
            },
            'today': {
                'logs': today_logs,
                'verified': today_verified,
                'unverified': today_logs - today_verified
            },
            'week': {
                'logs': week_logs,
                'verified': week_verified
            },
            'month': {
                'logs': month_logs
            },
            'average_similarity': round(avg_similarity, 4) if avg_similarity else 0,
            'recent_logs': [log.to_dict() for log in recent_logs],
            'hourly_distribution': hourly_data,
            'top_persons': [{'name': p, 'count': c} for p, c in top_persons],
            'door_stats': [{'door': d, 'count': c} for d, c in door_stats if d]
        }
    
    @staticmethod
    def get_daily_stats(days: int = 30) -> List[Dict[str, Any]]:
        """Get daily statistics for the last N days"""
        start_date = datetime.utcnow() - timedelta(days=days)
        
        daily_stats = db.session.query(
            func.date(RecognitionLog.timestamp).label('date'),
            func.count(RecognitionLog.id).label('total'),
            func.sum(
                func.cast(RecognitionLog.identity_verified, db.Integer)
            ).label('verified')
        ).filter(
            RecognitionLog.timestamp >= start_date
        ).group_by(
            func.date(RecognitionLog.timestamp)
        ).order_by(
            func.date(RecognitionLog.timestamp)
        ).all()
        
        return [
            {
                'date': str(stat.date),
                'total': stat.total,
                'verified': stat.verified or 0,
                'unverified': stat.total - (stat.verified or 0)
            }
            for stat in daily_stats
        ]
    
    @staticmethod
    def get_config_snapshots(
        page: int = 1,
        per_page: int = 20
    ) -> Tuple[List[ConfigSnapshot], int]:
        """Get configuration snapshots with pagination"""
        query = ConfigSnapshot.query.order_by(desc(ConfigSnapshot.snapshot_time))
        total = query.count()
        snapshots = query.offset((page - 1) * per_page).limit(per_page).all()
        return snapshots, total
    
    @staticmethod
    def get_latest_config_snapshot() -> Optional[ConfigSnapshot]:
        """Get the most recent configuration snapshot"""
        return ConfigSnapshot.query.order_by(
            desc(ConfigSnapshot.snapshot_time)
        ).first()
    
    @staticmethod
    def search_logs(
        query_text: str,
        limit: int = 50
    ) -> List[RecognitionLog]:
        """Search logs by person name"""
        return RecognitionLog.query.filter(
            RecognitionLog.recognized_person.ilike(f'%{query_text}%')
        ).order_by(
            desc(RecognitionLog.timestamp)
        ).limit(limit).all()
