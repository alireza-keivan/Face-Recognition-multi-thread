#!/usr/bin/env python3
"""
face_service.py - Face management service
Handles known faces CRUD operations and triggers service restart
"""

import os
import shutil
import pickle
import logging
from pathlib import Path
from typing import List, Dict, Any, Optional, Tuple
from datetime import datetime
from PIL import Image
import subprocess

logger = logging.getLogger(__name__)


class FaceService:
    """Service for managing known faces"""

    def __init__(self, config):
        self.config = config
        self.known_faces_dir = Path(config.KNOWN_FACES_DIR)
        self.encodings_file = Path(config.ENCODINGS_FILE)
        self.uploads_dir = Path(config.UPLOADS_DIR)
        self.service_name = config.SERVICE_NAME
        self.project_dir = Path(config.PROJECT_DIR)

        # Ensure directories exist
        self.known_faces_dir.mkdir(parents=True, exist_ok=True)
        self.uploads_dir.mkdir(parents=True, exist_ok=True)

    # ============================================================
    # FETCHING FACE DATA
    # ============================================================
    
    def get_all_faces(self) -> List[Dict[str, Any]]:
        """
        Return list of all known people with their face images.
        
        Returns:
            List of dictionaries containing person info and images
        """
        faces = []

        if not self.known_faces_dir.exists():
            return faces

        for person_dir in self.known_faces_dir.iterdir():
            if person_dir.is_dir():
                images = []
                for img_file in person_dir.iterdir():
                    if img_file.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp"]:
                        images.append({
                            "filename": img_file.name,
                            "path": str(img_file.relative_to(self.project_dir)),
                            "size": img_file.stat().st_size,
                            "modified": datetime.fromtimestamp(
                                img_file.stat().st_mtime
                            ).isoformat()
                        })

                if images:
                    faces.append({
                        "name": person_dir.name,
                        "image_count": len(images),
                        "images": images,
                        "created": datetime.fromtimestamp(
                            person_dir.stat().st_ctime
                        ).isoformat()
                    })

        faces.sort(key=lambda x: x["name"].lower())
        return faces

    def get_face(self, person_name: str) -> Optional[Dict[str, Any]]:
        """
        Return details of a specific person.
        
        Args:
            person_name: Name of the person to retrieve
            
        Returns:
            Dictionary with person info or None if not found
        """
        person_dir = self.known_faces_dir / person_name
        
        if not person_dir.exists() or not person_dir.is_dir():
            return None

        images = []
        for img_file in person_dir.iterdir():
            if img_file.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp"]:
                images.append({
                    "filename": img_file.name,
                    "path": str(img_file.relative_to(self.project_dir)),
                    "size": img_file.stat().st_size,
                    "modified": datetime.fromtimestamp(
                        img_file.stat().st_mtime
                    ).isoformat()
                })

        return {
            "name": person_name,
            "image_count": len(images),
            "images": images,
            "created": datetime.fromtimestamp(
                person_dir.stat().st_ctime
            ).isoformat()
        }

    def get_faces_count(self) -> int:
        """Return total number of known persons."""
        if not self.known_faces_dir.exists():
            return 0
        
        count = 0
        for person_dir in self.known_faces_dir.iterdir():
            if person_dir.is_dir():
                count += 1
        return count

    def get_total_images_count(self) -> int:
        """Return total number of face images across all persons."""
        if not self.known_faces_dir.exists():
            return 0
        
        total = 0
        for person_dir in self.known_faces_dir.iterdir():
            if person_dir.is_dir():
                for img_file in person_dir.iterdir():
                    if img_file.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp"]:
                        total += 1
        return total

    # ============================================================
    # ADDING FACE IMAGES
    # ============================================================
    
    def add_face(
        self,
        person_name: str,
        image_files: List[Any],
        restart_service: bool = True
    ) -> Tuple[bool, str]:
        """
        Add new person or add images to existing one.
        
        Args:
            person_name: Name of the person
            image_files: List of uploaded file objects (from Flask request.files)
            restart_service: Whether to restart the face recognition service
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        # Sanitize and validate person name
        person_name = self._sanitize_name(person_name)
        if not person_name:
            return False, "نام وارد شده معتبر نیست."

        if len(person_name) < 2:
            return False, "نام باید حداقل ۲ کاراکتر باشد."

        # Create person directory
        person_dir = self.known_faces_dir / person_name
        person_dir.mkdir(parents=True, exist_ok=True)

        saved_count = 0
        errors = []

        for file in image_files:
            try:
                # Skip empty files
                if not file or not file.filename:
                    continue

                # Validate image format
                if not self._validate_image(file):
                    errors.append(f"فایل {file.filename} یک تصویر معتبر نیست.")
                    continue

                # Generate unique filename
                filename = self._generate_filename(file.filename)
                filepath = person_dir / filename

                # Reset file pointer and save
                file.seek(0)
                file.save(str(filepath))

                # Verify the saved image
                if not self._verify_saved_image(filepath):
                    errors.append(f"خطا در ذخیره فایل {file.filename}")
                    filepath.unlink(missing_ok=True)
                    continue

                saved_count += 1
                logger.info(f"Saved image: {filepath}")

            except Exception as e:
                logger.error(f"Error saving image {file.filename}: {e}")
                errors.append(f"خطای داخلی هنگام ذخیره {file.filename}")

        # If no images were saved
        if saved_count == 0:
            # Remove empty directory if created
            if person_dir.exists() and not any(person_dir.iterdir()):
                person_dir.rmdir()
            error_msg = "; ".join(errors) if errors else "هیچ تصویری ذخیره نشد."
            return False, error_msg

        # Rebuild encodings after adding images
        rebuild_success = self._rebuild_encodings()

        # Restart service if requested
        if restart_service:
            self._restart_service()

        # Prepare response message
        if errors:
            return True, f"{saved_count} تصویر ذخیره شد. خطاها: {'; '.join(errors)}"
        
        return True, f"{saved_count} تصویر با موفقیت برای '{person_name}' ذخیره شد."

    # ============================================================
    # REMOVING FACES AND IMAGES
    # ============================================================
    
    def delete_person(
        self,
        person_name: str,
        restart_service: bool = True
    ) -> Tuple[bool, str]:
        """
        Delete a person and all their images.
        
        Args:
            person_name: Name of the person to delete
            restart_service: Whether to restart the face recognition service
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        person_dir = self.known_faces_dir / person_name

        if not person_dir.exists():
            return False, f"شخصی با نام '{person_name}' یافت نشد."

        try:
            # Count images before deletion
            image_count = sum(
                1 for f in person_dir.iterdir()
                if f.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp"]
            )

            # Remove the directory and all contents
            shutil.rmtree(person_dir)
            logger.info(f"Deleted person directory: {person_dir}")

            # Rebuild encodings
            self._rebuild_encodings()

            # Restart service if requested
            if restart_service:
                self._restart_service()

            return True, f"'{person_name}' به همراه {image_count} تصویر حذف شد."

        except Exception as e:
            logger.error(f"Error deleting person {person_name}: {e}")
            return False, f"خطا در حذف: {str(e)}"

    def delete_image(
        self,
        person_name: str,
        filename: str,
        restart_service: bool = True
    ) -> Tuple[bool, str]:
        """
        Delete a specific image from a person.
        
        Args:
            person_name: Name of the person
            filename: Name of the image file to delete
            restart_service: Whether to restart the face recognition service
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        person_dir = self.known_faces_dir / person_name
        image_path = person_dir / filename

        if not image_path.exists():
            return False, f"تصویر '{filename}' یافت نشد."

        try:
            # Delete the image
            image_path.unlink()
            logger.info(f"Deleted image: {image_path}")

            # Check if person directory is now empty
            remaining_images = [
                f for f in person_dir.iterdir()
                if f.suffix.lower() in [".jpg", ".jpeg", ".png", ".bmp"]
            ]

            # If no images left, remove the person directory
            if not remaining_images:
                shutil.rmtree(person_dir)
                logger.info(f"Removed empty person directory: {person_dir}")
                message = f"تصویر حذف شد. پوشه '{person_name}' نیز به دلیل خالی بودن حذف شد."
            else:
                message = f"تصویر '{filename}' حذف شد. {len(remaining_images)} تصویر باقی‌مانده."

            # Rebuild encodings
            self._rebuild_encodings()

            # Restart service if requested
            if restart_service:
                self._restart_service()

            return True, message

        except Exception as e:
            logger.error(f"Error deleting image {filename}: {e}")
            return False, f"خطا در حذف تصویر: {str(e)}"

    def rename_person(
        self,
        old_name: str,
        new_name: str,
        restart_service: bool = True
    ) -> Tuple[bool, str]:
        """
        Rename a person.
        
        Args:
            old_name: Current name of the person
            new_name: New name for the person
            restart_service: Whether to restart the face recognition service
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        old_dir = self.known_faces_dir / old_name
        
        if not old_dir.exists():
            return False, f"شخصی با نام '{old_name}' یافت نشد."

        new_name = self._sanitize_name(new_name)
        if not new_name:
            return False, "نام جدید معتبر نیست."

        new_dir = self.known_faces_dir / new_name

        if new_dir.exists():
            return False, f"شخصی با نام '{new_name}' از قبل وجود دارد."

        try:
            old_dir.rename(new_dir)
            logger.info(f"Renamed person: {old_name} -> {new_name}")

            # Rebuild encodings
            self._rebuild_encodings()

            # Restart service if requested
            if restart_service:
                self._restart_service()

            return True, f"نام '{old_name}' به '{new_name}' تغییر یافت."

        except Exception as e:
            logger.error(f"Error renaming person: {e}")
            return False, f"خطا در تغییر نام: {str(e)}"

    # ============================================================
    # INTERNAL UTILITY FUNCTIONS
    # ============================================================
    
    def _sanitize_name(self, name: str) -> str:
        """
        Sanitize person name by removing dangerous characters.
        
        Args:
            name: Raw input name
            
        Returns:
            Sanitized name string
        """
        if not name:
            return ""
        
        # Strip whitespace
        name = name.strip()
        
        # Replace dangerous characters
        dangerous_chars = ['/', '\\', '..', '<', '>', ':', '"', '|', '?', '*']
        for char in dangerous_chars:
            name = name.replace(char, '_')
        
        # Remove leading/trailing dots and spaces
        name = name.strip('. ')
        
        return name

    def _validate_image(self, file) -> bool:
        """
        Validate that the file is a valid image.
        
        Args:
            file: File object to validate
            
        Returns:
            True if valid image, False otherwise
        """
        try:
            # Check file extension
            if not file.filename:
                return False
            
            ext = Path(file.filename).suffix.lower()
            if ext not in ['.jpg', '.jpeg', '.png', '.bmp', '.gif']:
                return False

            # Try to open and verify with PIL
            file.seek(0)
            img = Image.open(file)
            img.verify()
            
            # Reset file pointer for later use
            file.seek(0)
            return True

        except Exception as e:
            logger.warning(f"Image validation failed: {e}")
            return False

    def _generate_filename(self, original_filename: str) -> str:
        """
        Generate a unique filename based on timestamp.
        
        Args:
            original_filename: Original filename from upload
            
        Returns:
            New unique filename
        """
        ext = Path(original_filename).suffix.lower()
        if ext not in ['.jpg', '.jpeg', '.png', '.bmp']:
            ext = '.jpg'
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
        return f"{timestamp}{ext}"

    def _verify_saved_image(self, filepath: Path) -> bool:
        """
        Verify that a saved image is valid and readable.
        
        Args:
            filepath: Path to the saved image
            
        Returns:
            True if valid, False otherwise
        """
        try:
            if not filepath.exists():
                return False

            img = Image.open(filepath)
            img.verify()
            return True

        except Exception as e:
            logger.error(f"Saved image verification failed for {filepath}: {e}")
            return False

    # ============================================================
    # REBUILD ENCODINGS
    # ============================================================

    def _rebuild_encodings(self) -> bool:
        """
        Rebuild the face encodings pickle file from all known images.
        
        Returns:
            True if successful, False otherwise
        """
        try:
            logger.info("Rebuilding face encodings...")

            all_names = []
            all_encodings = []

            # Lazy import to avoid heavy startup
            from insightface.app import FaceAnalysis
            import numpy as np

            app = FaceAnalysis(name='buffalo_l', providers=['CPUExecutionProvider'])
            app.prepare(ctx_id=-1, det_size=(320, 320))

            for person_dir in self.known_faces_dir.iterdir():
                if not person_dir.is_dir():
                    continue

                person_name = person_dir.name

                for img_file in person_dir.iterdir():
                    if img_file.suffix.lower() not in [".jpg", ".jpeg", ".png", ".bmp"]:
                        continue

                    try:
                        img = Image.open(img_file).convert("RGB")
                        img_np = np.array(img)

                        faces = app.get(img_np)

                        if len(faces) == 0:
                            logger.warning(f"No face detected in image: {img_file}")
                            continue

                        embedding = faces[0].embedding

                        all_names.append(person_name)
                        all_encodings.append(embedding)

                    except Exception as e:
                        logger.error(f"Encoding failed for {img_file}: {e}")

            # Save to pickle
            data = {
                "names": all_names,
                "encodings": all_encodings
            }

            with open(self.encodings_file, "wb") as f:
                pickle.dump(data, f)

            logger.info(f"Successfully rebuilt encodings file with {len(all_names)} faces.")
            return True

        except Exception as e:
            logger.error(f"Failed to rebuild encodings: {e}")
            return False

    # ============================================================
    # RESTART SERVICE
    # ============================================================

    def _restart_service(self) -> bool:
        """
        Restart the face recognition systemd service.
        
        Returns:
            True if restart successful, False otherwise
        """
        try:
            logger.info(f"Restarting service: {self.service_name}")

            result = subprocess.run(
                ["sudo", "systemctl", "restart", self.service_name],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )

            if result.returncode == 0:
                logger.info("Service restarted successfully.")
                return True
            else:
                logger.error(f"Service restart failed: {result.stderr.decode().strip()}")
                return False

        except Exception as e:
            logger.error(f"Error restarting service: {e}")
            return False
