#!/usr/bin/env python3
"""
system_service.py - Handle config.json operations + restart main service
"""

import json
import logging
import subprocess
from pathlib import Path
from typing import Dict, Any

logger = logging.getLogger(__name__)


class SystemService:
    """Manage system configs, files, and restart logic."""

    def __init__(self, config):
        self.config = config
        self.config_file = Path(config.CONFIG_JSON_PATH)
        self.service_name = config.SERVICE_NAME

    # ------------------------------------------------------------
    # CONFIG.JSON MANAGEMENT
    # ------------------------------------------------------------
    def read_config(self) -> Dict[str, Any]:
        if not self.config_file.exists():
            return {}

        with open(self.config_file, "r") as f:
            return json.load(f)

    def update_config(self, new_data: Dict[str, Any], restart_service: bool = True) -> bool:
        try:
            with open(self.config_file, "w") as f:
                json.dump(new_data, f, indent=4)

            if restart_service:
                self.restart_service()

            return True

        except Exception as e:
            logger.error(f"Failed to update config.json: {e}")
            return False

    # ------------------------------------------------------------
    # SERVICE RESTART
    # ------------------------------------------------------------
    def restart_service(self) -> bool:
        try:
            subprocess.run(
                ["sudo", "systemctl", "restart", self.service_name],
                check=True
            )
            return True
        except Exception as e:
            logger.error(f"Failed to restart service: {e}")
            return False

    # ------------------------------------------------------------
    # SYSTEM DEPLOYMENT UTILITIES
    # ------------------------------------------------------------
    def get_service_status(self) -> Dict[str, Any]:
        try:
            p = subprocess.run(
                ["systemctl", "status", self.service_name],
                capture_output=True,
                text=True
            )
            return {
                "running": p.returncode == 0,
                "output": p.stdout,
                "error": p.stderr,
            }
        except Exception as e:
            return {
                "running": False,
                "error": str(e)
            }
