"""
Configuration for Face Recognition Web Admin
"""
import os

# Secret Key for Flask sessions
SECRET_KEY = os.environ.get('SECRET_KEY', 'face-recognition-admin-secret-key-2024')

# Database Configuration
DB_CONFIG = {
    'host': 'localhost',
    'port': 5432,
    'database': 'face_recognition_db',
    'user': 'face_user',
    'password': '123456'
}

# Paths Configuration
BASE_DIR = '/home/face/Face-Recognition-multi-thread'
KNOWN_FACES_DIR = os.path.join(BASE_DIR, 'captured_known_faces')
ENCODINGS_FILE = os.path.join(BASE_DIR, 'known_faces_data.pkl')
CONFIG_FILE = os.path.join(BASE_DIR, 'config.json')

# Service Configuration
FACE_SERVICE_NAME = 'face-recognition.service'

# Upload Configuration
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size

# Pagination
ITEMS_PER_PAGE = 20
