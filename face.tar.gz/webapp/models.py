#!/usr/bin/env python3
"""
models.py - SQLAlchemy Models matching existing database schema
"""

from datetime import datetime
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()


class RecognitionLog(db.Model):
    """
    Model for recognition_logs table
    Matches existing database schema exactly
    """
    __tablename__ = 'recognition_logs'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    recognized_person = db.Column(db.String(255), nullable=False, index=True)
    identity_verified = db.Column(db.Boolean, nullable=False)
    cosine_similarity = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, nullable=False, index=True)
    image_path = db.Column(db.String(512))
    image_filename = db.Column(db.String(255))
    face_x1 = db.Column(db.Integer)
    face_y1 = db.Column(db.Integer)
    face_x2 = db.Column(db.Integer)
    face_y2 = db.Column(db.Integer)
    door_num = db.Column(db.Integer)
    region_x1 = db.Column(db.Integer)
    region_y1 = db.Column(db.Integer)
    region_x2 = db.Column(db.Integer)
    region_y2 = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Composite indexes (already exist in DB)
    __table_args__ = (
        db.Index('idx_person_timestamp', 'recognized_person', 'timestamp'),
        db.Index('idx_verified_timestamp', 'identity_verified', 'timestamp'),
    )
    
    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'recognized_person': self.recognized_person,
            'identity_verified': self.identity_verified,
            'cosine_similarity': round(self.cosine_similarity, 4) if self.cosine_similarity else None,
            'timestamp': self.timestamp.isoformat() if self.timestamp else None,
            'image_path': self.image_path,
            'image_filename': self.image_filename,
            'face_coordinates': {
                'x1': self.face_x1,
                'y1': self.face_y1,
                'x2': self.face_x2,
                'y2': self.face_y2
            } if self.face_x1 else None,
            'operation_region': {
                'x1': self.region_x1,
                'y1': self.region_y1,
                'x2': self.region_x2,
                'y2': self.region_y2
            } if self.region_x1 else None,
            'door_num': self.door_num,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f'<RecognitionLog {self.id}: {self.recognized_person}>'


class ConfigSnapshot(db.Model):
    """
    Model for config_snapshots table
    Matches existing database schema exactly
    """
    __tablename__ = 'config_snapshots'
    
    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    snapshot_time = db.Column(db.DateTime, nullable=False, index=True)
    service_start_id = db.Column(db.String(64))
    config_data = db.Column(db.JSON, nullable=False)
    camera_url = db.Column(db.String(512))
    mqtt_broker = db.Column(db.String(255))
    mqtt_topic = db.Column(db.String(255))
    known_faces_dir = db.Column(db.String(512))
    cosine_threshold = db.Column(db.Float)
    door_num = db.Column(db.Integer)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        """Convert model to dictionary"""
        return {
            'id': self.id,
            'snapshot_time': self.snapshot_time.isoformat() if self.snapshot_time else None,
            'service_start_id': self.service_start_id,
            'config_data': self.config_data,
            'camera_url': self.camera_url,
            'mqtt_broker': self.mqtt_broker,
            'mqtt_topic': self.mqtt_topic,
            'known_faces_dir': self.known_faces_dir,
            'cosine_threshold': self.cosine_threshold,
            'door_num': self.door_num,
            'created_at': self.created_at.isoformat() if self.created_at else None
        }
    
    def __repr__(self):
        return f'<ConfigSnapshot {self.id}: {self.snapshot_time}>'
