from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, send_from_directory, session
import os
import json
import shutil
import subprocess
from datetime import datetime
import psycopg2
import psycopg2
from psycopg2.extras import RealDictCursor
import jdatetime
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'face-recognition-secret-key-2024'

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'
login_manager.login_message = 'لطفا ابتدا وارد شوید'  # Persian login message

# Import database models and manager
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from database import db_manager, User

@login_manager.user_loader
def load_user(user_id):
    """Load user by ID for Flask-Login."""
    try:
        session = db_manager.get_session()
        user = session.query(User).get(int(user_id))
        if user:
            # Make the object completely independent using make_transient
            from sqlalchemy.orm import make_transient
            make_transient(user)
        session.close()
        return user
    except Exception as e:
        print(f"Error loading user: {e}")
        import traceback
        traceback.print_exc()
        return None

# Add Jalali date filter for Jinja2 templates
@app.template_filter('jalali')
def jalali_filter(value):
    """Convert datetime to Jalali (Persian) format"""
    if value is None:
        return ''
    try:
        # If value is string, parse it first
        if isinstance(value, str):
            value = datetime.fromisoformat(value.replace('Z', '+00:00'))
        
        # Convert to Jalali
        jdt = jdatetime.datetime.fromgregorian(datetime=value)
        return jdt.strftime('%Y/%m/%d %H:%M:%S')
    except Exception as e:
        return str(value)

# ===== Authentication Routes =====
@app.route('/login', methods=['GET', 'POST'])
def login():
    """Login page"""
    if current_user.is_authenticated:
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        password = request.form.get('password', '')
        
        if not username or not password:
            flash('نام کاربری و رمز عبور الزامی است', 'danger')
            return render_template('login.html')
        
        try:
            session_db = db_manager.get_session()
            user = session_db.query(User).filter_by(username=username).first()
            
            if user and user.check_password(password):
                if not user.is_active:
                    flash('حساب کاربری شما غیرفعال است', 'danger')
                    session_db.close()
                    return render_template('login.html')
                
                # Update last login
                user.last_login = datetime.utcnow()
                session_db.commit()
                
                # Refresh to get the updated data
                session_db.refresh(user)
                
                # Make object independent - use make_transient to detach completely
                from sqlalchemy.orm import make_transient
                make_transient(user)
                session_db.close()
                
                login_user(user, remember=True)
                flash(f'خوش آمدید {username}!', 'success')
                
                # Redirect to next page or dashboard
                next_page = request.args.get('next')
                return redirect(next_page) if next_page else redirect(url_for('dashboard'))
            else:
                flash('نام کاربری یا رمز عبور اشتباه است', 'danger')
                session_db.close()
        except Exception as e:
            flash(f'خطا در ورود: {str(e)}', 'danger')
            print(f"Login error: {e}")
            import traceback
            traceback.print_exc()
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
@login_required
def register():
    """Admin-only user creation page"""
    # Check if current user is admin
    if not current_user.is_admin:
        flash('فقط مدیر سیستم می‌تواند کاربر جدید ایجاد کند', 'danger')
        return redirect(url_for('dashboard'))
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip()
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        # Validation
        if not username or not password:
            flash('نام کاربری و رمز عبور الزامی است', 'danger')
            return render_template('register.html')
        
        if len(username) < 3:
            flash('نام کاربری باید حداقل ۳ کاراکتر باشد', 'danger')
            return render_template('register.html')
        
        if len(password) < 6:
            flash('رمز عبور باید حداقل ۶ کاراکتر باشد', 'danger')
            return render_template('register.html')
        
        if password != confirm_password:
            flash('رمز عبور و تکرار آن مطابقت ندارند', 'danger')
            return render_template('register.html')
        
        try:
            session_db = db_manager.get_session()
            
            # Check if username already exists
            existing_user = session_db.query(User).filter_by(username=username).first()
            if existing_user:
                flash('این نام کاربری قبلا ثبت شده است', 'danger')
                session_db.close()
                return render_template('register.html')
            
            # Check if email already exists
            if email:
                existing_email = session_db.query(User).filter_by(email=email).first()
                if existing_email:
                    flash('این ایمیل قبلا ثبت شده است', 'danger')
                    session_db.close()
                    return render_template('register.html')
            
            # Create new user
            new_user = User(username=username, email=email if email else None, is_admin=False)
            new_user.set_password(password)
            session_db.add(new_user)
            session_db.commit()
            session_db.close()
            
            flash(f'کاربر "{username}" با موفقیت ایجاد شد', 'success')
            return redirect(url_for('users_list'))
            
        except Exception as e:
            flash(f'خطا در ایجاد کاربر: {str(e)}', 'danger')
            print(f"User creation error: {e}")
    
    return render_template('register.html', is_admin_page=True)

@app.route('/users')
@login_required
def users_list():
    """List all users (admin only)"""
    if not current_user.is_admin:
        flash('فقط مدیر سیستم می‌تواند لیست کاربران را مشاهده کند', 'danger')
        return redirect(url_for('dashboard'))
    
    try:
        session_db = db_manager.get_session()
        users = session_db.query(User).order_by(User.created_at.desc()).all()
        
        # Create a list of user dicts to avoid session issues
        users_data = []
        for user in users:
            users_data.append({
                'id': user.id,
                'username': user.username,
                'email': user.email,
                'is_admin': user.is_admin,
                'is_active': user.is_active,
                'created_at': user.created_at,
                'last_login': user.last_login
            })
        session_db.close()
        
        return render_template('users_list.html', users=users_data)
    except Exception as e:
        flash(f'خطا در دریافت لیست کاربران: {str(e)}', 'danger')
        return redirect(url_for('dashboard'))

@app.route('/users/delete/<int:user_id>', methods=['POST'])
@login_required
def delete_user(user_id):
    """Delete a user (admin only)"""
    if not current_user.is_admin:
        flash('فقط مدیر سیستم می‌تواند کاربر را حذف کند', 'danger')
        return redirect(url_for('dashboard'))
    
    try:
        session_db = db_manager.get_session()
        user = session_db.query(User).get(user_id)
        
        if not user:
            flash('کاربر یافت نشد', 'danger')
            session_db.close()
            return redirect(url_for('users_list'))
        
        # Prevent deleting yourself
        if user.id == current_user.id:
            flash('نمی‌توانید حساب کاربری خود را حذف کنید', 'danger')
            session_db.close()
            return redirect(url_for('users_list'))
        
        # Prevent deleting the last admin
        if user.is_admin:
            admin_count = session_db.query(User).filter_by(is_admin=True).count()
            if admin_count <= 1:
                flash('نمی‌توانید آخرین مدیر سیستم را حذف کنید', 'danger')
                session_db.close()
                return redirect(url_for('users_list'))
        
        username = user.username
        session_db.delete(user)
        session_db.commit()
        session_db.close()
        
        flash(f'کاربر "{username}" با موفقیت حذف شد', 'success')
    except Exception as e:
        flash(f'خطا در حذف کاربر: {str(e)}', 'danger')
    
    return redirect(url_for('users_list'))

@app.route('/users/toggle-active/<int:user_id>', methods=['POST'])
@login_required
def toggle_user_active(user_id):
    """Toggle user active status (admin only)"""
    if not current_user.is_admin:
        flash('فقط مدیر سیستم می‌تواند وضعیت کاربر را تغییر دهد', 'danger')
        return redirect(url_for('dashboard'))
    
    try:
        session_db = db_manager.get_session()
        user = session_db.query(User).get(user_id)
        
        if not user:
            flash('کاربر یافت نشد', 'danger')
            session_db.close()
            return redirect(url_for('users_list'))
        
        # Prevent deactivating yourself
        if user.id == current_user.id:
            flash('نمی‌توانید حساب کاربری خود را غیرفعال کنید', 'danger')
            session_db.close()
            return redirect(url_for('users_list'))
        
        user.is_active = not user.is_active
        session_db.commit()
        
        status = 'فعال' if user.is_active else 'غیرفعال'
        flash(f'کاربر "{user.username}" {status} شد', 'success')
        session_db.close()
    except Exception as e:
        flash(f'خطا در تغییر وضعیت: {str(e)}', 'danger')
    
    return redirect(url_for('users_list'))

@app.route('/logout')
@login_required
def logout():
    """Logout user"""
    logout_user()
    flash('با موفقیت خارج شدید', 'info')
    return redirect(url_for('login'))


# ===== Configuration =====
BASE_DIR = '/home/face/Face-Recognition-multi-thread'
CONFIG_FILE = os.path.join(BASE_DIR, 'config.json')
KNOWN_FACES_DIR = os.path.join(BASE_DIR, 'captured_known_faces')
ENCODINGS_FILE = os.path.join(BASE_DIR, 'known_faces_data.pkl')
SAVED_FACES_DIR = '/home/face/Face-Recognition-multi-thread/saved_faces'
def load_config():
    """Load configuration from JSON file"""
    try:
        with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        print(f"Error loading config: {e}")
        return {}

def save_config(config):
    """Save configuration to JSON file"""
    try:
        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        print(f"Error saving config: {e}")
        return False

def get_persons():
    """Get list of all persons with their images (flat structure - files directly in folder)"""
    persons = []
    if os.path.exists(KNOWN_FACES_DIR):
        valid_extensions = ('.jpg', '.jpeg', '.png', '.bmp')
        for filename in sorted(os.listdir(KNOWN_FACES_DIR)):
            filepath = os.path.join(KNOWN_FACES_DIR, filename)
            if os.path.isfile(filepath) and filename.lower().endswith(valid_extensions):
                # Extract person name from filename (remove extension)
                name = os.path.splitext(filename)[0]
                persons.append({
                    'name': name,
                    'filename': filename,
                    'image_count': 1,
                    'images': [filename]
                })
    return persons

def get_service_status(service_name):
    """Check if a systemd service is running"""
    try:
        result = subprocess.run(
            ['systemctl', 'is-active', service_name],
            capture_output=True, text=True, timeout=5
        )
        return result.stdout.strip() == 'active'
    except:
        return False


@app.route('/face_image/<path:filename>')
def face_image(filename):
    """Serve face images from captured_known_faces directory"""
    return send_from_directory(KNOWN_FACES_DIR, filename)

# ===== Error Handlers =====
@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_error(e):
    return render_template('500.html'), 500

# ===== Routes =====

@app.route('/')
@login_required
def index():
    """Redirect to dashboard"""
    return redirect(url_for('dashboard'))

@app.route('/dashboard')
@login_required
def dashboard():
    """Dashboard page with system overview"""
    persons = get_persons()
    total_persons = len(persons)
    total_images = sum(p['image_count'] for p in persons)
    
    # Check service status
    face_service_active = get_service_status('face-recognition')
    
    # Get today's face detection statistics
    from database import RecognitionLog
    from datetime import timedelta
    
    session = db_manager.get_session()
    today_start = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    
    # Total faces detected today
    faces_today = session.query(RecognitionLog).filter(
        RecognitionLog.timestamp >= today_start
    ).count()
    
    # Known faces today (is_verified = True)
    known_faces_today = session.query(RecognitionLog).filter(
        RecognitionLog.timestamp >= today_start,
        RecognitionLog.identity_verified == True
    ).count()
    
    # Unknown faces today (is_verified = False)
    unknown_faces_today = faces_today - known_faces_today
    
    # Get current Jalali date
    jdt = jdatetime.datetime.now()
    jalali_date = jdt.strftime('%Y/%m/%d')
    
    session.close()
    
    return render_template('dashboard.html',
                         total_persons=total_persons,
                         total_images=total_images,
                         face_service_active=face_service_active,
                         faces_today=faces_today,
                         known_faces_today=known_faces_today,
                         unknown_faces_today=unknown_faces_today,
                         jalali_date=jalali_date)

@app.route('/faces')
@app.route('/persons')  # هر دو URL کار کنند
@login_required
def faces():
    """List all persons/faces"""
    persons = get_persons()
    return render_template('faces.html', persons=persons)

@app.route('/person/<name>')
@login_required
def person_detail(name):
    """View details of a specific person"""
    person_path = os.path.join(KNOWN_FACES_DIR, name)
    if not os.path.exists(person_path):
        flash('فرد مورد نظر یافت نشد', 'error')
        return redirect(url_for('faces'))
    
    images = [f for f in os.listdir(person_path) 
             if f.lower().endswith(('.jpg', '.jpeg', '.png', '.bmp'))]
    
    return render_template('person_detail.html', 
                         person_name=name, 
                         images=images)

@app.route('/add_person', methods=['GET', 'POST'])
@login_required
def add_person():
    """Add a new person"""
    if request.method == 'POST':
        person_name = request.form.get('name', '').strip()
        
        if not person_name:
            flash('نام فرد نمی‌تواند خالی باشد', 'error')
            return redirect(url_for('add_person'))
        
        # Sanitize name
        person_name = "".join(c for c in person_name if c.isalnum() or c in (' ', '-', '_')).strip()
        person_name = person_name.replace(' ', '_')
        
        if not person_name:
            flash('نام فرد نامعتبر است', 'error')
            return redirect(url_for('add_person'))
        
        try:

            
            # Handle uploaded files
            files = request.files.getlist('images')
            
            for file in files:
                if file and file.filename:
                    ext = os.path.splitext(file.filename)[1].lower()
                    if ext in ['.jpg', '.jpeg', '.png', '.bmp']:
                        filename = f"{person_name}{ext}"
                        person_path = os.path.join(KNOWN_FACES_DIR, filename)
                        file.save(os.path.join(person_path))
                        saved_count = 1
                        os.remove(ENCODINGS_FILE)
                        #subprocess.Popen(['sudo', 'rm', '-rf', '/home/face/Face-Recognition-multi-thread/known_faces_data.pkl'])
                        subprocess.Popen(['sudo', 'systemctl', 'restart', 'face-recognition.service'])
            flash(f'فرد "{person_name}" با {saved_count} تصویر اضافه شد', 'success')
            return redirect(url_for('faces'))
            
        except Exception as e:
            flash(f'خطا در ایجاد فرد: {str(e)}', 'error')
            return redirect(url_for('add_person'))
    
    return render_template('add_person.html')

@app.route('/delete_person/<filename>', methods=['POST'])
@login_required
def delete_person(filename):
    """Delete a person and all their images"""
    file_path = os.path.join(KNOWN_FACES_DIR, filename)
    
    if os.path.isfile(file_path):
        try:
            os.remove(file_path)
            flash(f'فرد "{filename}" با موفقیت حذف شد', 'success')
            os.remove(ENCODINGS_FILE)
            #subprocess.Popen(['sudo', 'rm', '-rf', '/home/face/Face-Recognition-multi-thread/known_faces_data.pkl'])
            subprocess.Popen(['sudo', 'systemctl', 'restart', 'face-recognition.service'])
        except Exception as e:
            flash(f'خطا در حذف: {str(e)}', 'error')
    else:
        flash('فرد مورد نظر یافت نشد', 'error')
    
    return redirect(url_for('faces'))


@app.route('/delete_image/<filename>', methods=['POST'])
@login_required
def delete_image(filename):
    """Delete a specific image"""
    file_path = os.path.join(KNOWN_FACES_DIR, filename)
    
    if os.path.isfile(file_path):
        try:
            os.remove(file_path)
            subprocess.Popen(['sudo', 'rm', '-rf', 'known_faces_data.pkl'])
            flash('تصویر با موفقیت حذف شد', 'success')
        except Exception as e:
            flash(f'خطا در حذف تصویر: {str(e)}', 'error')
    else:
        flash('تصویر یافت نشد', 'error')
    
    return redirect(url_for('faces'))


def get_db_connection():
    """ایجاد اتصال به دیتابیس PostgreSQL"""
    try:
        conn = psycopg2.connect(
            host='localhost',
            database='face_recognition_db',
            user='face_user',
            password='123456'
        )
        return conn
    except Exception as e:
        print(f"Database connection error: {e}")
        return None




@app.route('/settings', methods=['GET', 'POST'])
@login_required
def settings():
    config = load_config()

    # اطمینان از وجود تمامی بخش‌ها
    config.setdefault("camera_settings", {})
    config.setdefault("face_recognition_settings", {})
    config.setdefault("mqtt_settings", {})
    config.setdefault("operation_region", {})
    config.setdefault("optimization_settings", {})
    config.setdefault("directories", {})

    if request.method == 'POST':
        try:
            # ===== Camera Settings =====
            camera = config["camera_settings"]
            camera["url"] = request.form.get("camera_url", "")
            camera["stream_id"] = request.form.get("stream_id", "0")
            camera["fps_limit"] = float(request.form.get("fps_limit", 5.0))
            camera["resize_scale"] = float(request.form.get("resize_scale", 0.5))
            camera["OUTPUT_WINDOW_NAME"] = request.form.get("window_name", "Face Recognition")
            camera["WINDOW_WIDTH"] = int(request.form.get("window_width", 1200))
            camera["WINDOW_HEIGHT"] = int(request.form.get("window_height", 1000))

            # ===== Face Recognition Settings =====
            fr = config["face_recognition_settings"]
            fr["COSINE_SIMILARITY_THRESHOLD"] = float(request.form.get("cosine_threshold", 0.35))
            fr["PROCESS_FRAME_SCALE"] = float(request.form.get("process_frame_scale", 0.2))
            fr["DOOR_OPEN_COOLDOWN"] = float(request.form.get("door_open_cooldown", 10))
            fr["RESET_DOOR_TIMER"] = float(request.form.get("reset_door_timer", 10))
            fr["IMAGE_SEND_COOLDOWN"] = float(request.form.get("image_cooldown", 5))
            fr["detection_width"] = int(request.form.get("detection_width", 320))
            fr["detection_height"] = int(request.form.get("detection_height", 320))

            # ===== MQTT Settings =====
            mqtt_cfg = config["mqtt_settings"]
            mqtt_cfg["MQTT_BROKER_ADDRESS"] = request.form.get("mqtt_broker", "")
            mqtt_cfg["MQTT_BROKER_PORT"] = int(request.form.get("mqtt_port", 1883))
            mqtt_cfg["MQTT_CLIENT_ID"] = request.form.get("mqtt_client_id", "")
            mqtt_cfg["MQTT_USERNAME"] = request.form.get("mqtt_username", "")
            mqtt_cfg["MQTT_PASSWORD"] = request.form.get("mqtt_password", "")
            mqtt_cfg["MQTT_FACE_TOPIC"] = request.form.get("mqtt_face_topic", "v1/devices/me/telemetry")

            # ===== Operation Region =====
            op = config["operation_region"]
            op["x1"] = int(request.form.get("roi_x1", 0))
            op["y1"] = int(request.form.get("roi_y1", 0))
            op["x2"] = int(request.form.get("roi_x2", 0))
            op["y2"] = int(request.form.get("roi_y2", 0))
            op["door_num"] = int(request.form.get("door_num", 1))

            # ===== Optimization Settings =====
            opt = config["optimization_settings"]
            opt["detection_interval_seconds"] = float(request.form.get("detection_interval", 5.0))
            opt["tracker_type"] = request.form.get("tracker_type", "KCF")

            # ===== Directory Settings =====
            directories = config["directories"]
            directories["KNOWN_FACES_DIR"] = request.form.get("known_faces_dir", directories.get("KNOWN_FACES_DIR", ""))
            directories["ENCODINGS_FILE"] = request.form.get("encodings_file", directories.get("ENCODINGS_FILE", ""))

            if save_config(config):
                flash("تنظیمات با موفقیت ذخیره شد", "success")
                subprocess.Popen(['sudo', 'systemctl', 'restart', 'face-recognition.service'])
            else:
                flash("خطا در ذخیره‌سازی فایل تنظیمات", "error")

        except Exception as e:
            flash(f"خطا در پردازش تنظیمات: {str(e)}", "error")

        return redirect(url_for("settings"))

    # GET Request → نمایش صفحه تنظیمات
    return render_template("settings.html", config=config)


@app.route('/rebuild_encodings', methods=['POST'])
@login_required
def rebuild_encodings():
    """Rebuild face encodings"""
    try:
        # This would trigger the encoding rebuild process
        flash('درخواست بازسازی encoding ها ارسال شد', 'success')
    except Exception as e:
        flash(f'خطا: {str(e)}', 'error')
    
    return redirect(url_for('settings'))

@app.route('/api/stats')
@login_required
def api_stats():
    """API endpoint for dashboard stats"""
    persons = get_persons()
    return jsonify({
        'total_persons': len(persons),
        'total_images': sum(p['image_count'] for p in persons),
        'face_service_active': get_service_status('face-recognition')
    })
    
    
from flask import send_from_directory
from database import DatabaseManager
db = DatabaseManager()
LOG_IMAGE_DIR = "/home/face/Face-Recognition-multi-thread/saved_faces"

@app.route('/log_images/<path:filename>')
def log_image(filename):
    """
    Serve face images from date-based folder structure.
    Supports both new structure (YYYY/MonthName/DD/file.jpg) and legacy flat structure.
    """
    SAVED_FACES_DIR = '/home/face/Face-Recognition-multi-thread/saved_faces'
    # The filename parameter already contains the relative path (e.g., '2025/December/27/John-2025-12-27-14-30-45.jpg')
    # send_from_directory will handle the nested path automatically
    return send_from_directory(SAVED_FACES_DIR, filename)

@app.route('/logs')
@login_required
def logs():
    """صفحه مشاهده لاگ‌ها از دیتابیس"""
    logs_list = []
    error_message = None
    
    try:
        conn = get_db_connection()
        if conn is None:
            error_message = "خطا در اتصال به دیتابیس: اتصال برقرار نشد"
            return render_template('logs.html', logs=logs_list, error_message=error_message)
        
        cur = conn.cursor(cursor_factory=RealDictCursor)
        
        cur.execute("""
            SELECT 
                id,
                recognized_person as person,
                ROUND(CAST(cosine_similarity AS numeric) * 100, 1) as confidence,
                door_num as door,
                image_path,
                timestamp
            FROM recognition_logs 
            ORDER BY timestamp DESC 
            LIMIT 100
        """)
        
        logs_list = cur.fetchall()
        cur.close()
        conn.close()
        
    except Exception as e:
        error_message = f"خطا در اتصال به دیتابیس: {str(e)}"
        print(f"Database error in /logs route: {e}")  # Log to console for debugging
    
    return render_template('logs.html', logs=logs_list, error_message=error_message)


@app.route('/cameras')
@login_required
def cameras():
    """صفحه مدیریت دوربین‌ها"""
    camera_info = {}
    
    try:
        if os.path.exists(CONFIG_FILE):
            with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                config = json.load(f)
                camera_info = config.get('camera_settings', {})
    except Exception as e:
        flash(f'خطا در بارگذاری تنظیمات دوربین: {str(e)}', 'danger')
    
    return render_template('cameras.html', camera_info=camera_info)



@app.route('/restart', methods=['POST'])
@login_required
def restart():
    """Restart the face recognition service"""
    import subprocess
    try:
        # Restart the systemd service (if exists)
        subprocess.Popen(['sudo', 'systemctl', 'restart', 'face-recognition.service'])
        flash('سرویس در حال ری‌استارت است...', 'success')
    except Exception as e:
        flash(f'خطا در ری‌استارت: {str(e)}', 'error')
    return redirect(url_for('settings'))



# ===== Run =====
if __name__ == '__main__':
    os.makedirs(LOG_IMAGE_DIR, exist_ok=True)
    app.run(host='0.0.0.0', port=5000, debug=True)

# ============================================
# روت‌های اضافی
# ============================================

