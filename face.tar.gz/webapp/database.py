import os
import json
import logging
from datetime import datetime
from typing import Optional, Dict, List, Union

from sqlalchemy import create_engine, Column, Integer, String, Float, Boolean, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin

# === Logger Setup ===
logger = logging.getLogger(__name__)

Base = declarative_base()

class User(Base, UserMixin):
    """User account for webapp authentication."""
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    username = Column(String(80), unique=True, nullable=False, index=True)
    email = Column(String(120), unique=True, nullable=True)
    password_hash = Column(String(255), nullable=False)
    is_admin = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    last_login = Column(DateTime, nullable=True)
    is_active = Column(Boolean, default=True)
    
    def set_password(self, password):
        """Hash and set password."""
        self.password_hash = generate_password_hash(password)
    
    def check_password(self, password):
        """Check if provided password matches hash."""
        return check_password_hash(self.password_hash, password)


class RecognitionLog(Base):
    """Stores each face recognition event."""
    __tablename__ = "recognition_logs"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    recognized_person = Column(String(255), nullable=False, index=True)
    identity_verified = Column(Boolean, nullable=False, default=False)
    cosine_similarity = Column(Float, nullable=True)
    timestamp = Column(DateTime, nullable=False, default=datetime.utcnow, index=True)
    image_path = Column(String(512), nullable=True)
    image_filename = Column(String(255), nullable=True)
    face_x1 = Column(Integer, nullable=True)
    face_y1 = Column(Integer, nullable=True)
    face_x2 = Column(Integer, nullable=True)
    face_y2 = Column(Integer, nullable=True)
    door_num = Column(Integer, nullable=True)
    region_x1 = Column(Integer, nullable=True)
    region_y1 = Column(Integer, nullable=True)
    region_x2 = Column(Integer, nullable=True)
    region_y2 = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class ConfigSnapshot(Base):
    """Stores configuration snapshots."""
    __tablename__ = "config_snapshots"
    
    id = Column(Integer, primary_key=True, autoincrement=True)
    config_json = Column(Text, nullable=False)
    service_start_id = Column(String(100), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


def _parse_bbox(bbox) -> tuple:
    """Parse face_bbox from list or dict format."""
    if bbox is None:
        return None, None, None, None
    
    # If it's a list: [x1, y1, x2, y2]
    if isinstance(bbox, (list, tuple)):
        if len(bbox) >= 4:
            return int(bbox[0]), int(bbox[1]), int(bbox[2]), int(bbox[3])
        return None, None, None, None
    
    # If it's a dict: {'x1': ..., 'y1': ..., 'x2': ..., 'y2': ...}
    if isinstance(bbox, dict):
        return (
            bbox.get('x1'),
            bbox.get('y1'),
            bbox.get('x2'),
            bbox.get('y2')
        )
    
    return None, None, None, None


def _parse_region(region) -> tuple:
    """Parse region from list or dict format."""
    if region is None:
        return None, None, None, None
    
    # If it's a list: [x1, y1, x2, y2]
    if isinstance(region, (list, tuple)):
        if len(region) >= 4:
            return int(region[0]), int(region[1]), int(region[2]), int(region[3])
        return None, None, None, None
    
    # If it's a dict
    if isinstance(region, dict):
        return (
            region.get('x1'),
            region.get('y1'),
            region.get('x2'),
            region.get('y2')
        )
    
    return None, None, None, None


class DatabaseManager:
    """Database manager for face recognition system."""
    
    def __init__(self):
        self.engine = None
        self.SessionLocal = None
        self._initialized = False

    def initialize(self, db_url: str = None):
        """Initialize database connection."""
        if self._initialized:
            return True

        try:
            if db_url is None:
                # Try to import config for database URL
                try:
                    # Try relative import first (when called from within webapp)
                    try:
                        from .config import DB_CONFIG
                    except ImportError:
                        # Try direct import (when webapp is in sys.path from thread.py)
                        from config import DB_CONFIG
                    
                    db_url = f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
                    logger.info(f"Using database config: {DB_CONFIG['user']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}")
                except (ImportError, KeyError) as e:
                    # Fallback to default (update with correct username)
                    db_url = "postgresql://face:123456@localhost:5432/face_recognition_db"
                    logger.warning(f"Failed to import config ({e}), using fallback database config")
            
            self.engine = create_engine(db_url, pool_pre_ping=True)
            self.SessionLocal = sessionmaker(bind=self.engine)
            Base.metadata.create_all(self.engine)
            self._initialized = True
            logger.info("✓ Database initialized successfully")
            return True
        except Exception as e:
            logger.error(f"✗ Database initialization failed: {e}")
            return False
    
    def get_session(self):
        """Get database session."""
        if not self._initialized:
            self.initialize()
        return self.SessionLocal()
    
    def log_recognition(
        self,
        recognized_person: str,
        identity_verified: bool,
        cosine_similarity: float = None,
        timestamp: datetime = None,
        image_path: Optional[str] = None,
        face_bbox = None,
        door_num: Optional[int] = None,
        region = None
    ) -> bool:
        """
        Log a face recognition event to the database.
        
        Args:
            recognized_person: Name of the recognized person
            identity_verified: Whether the identity was verified
            cosine_similarity: Similarity score (optional)
            timestamp: Event timestamp (defaults to current time if None)
            image_path: Path to saved face image
            face_bbox: Face bounding box as list [x1, y1, x2, y2] or dict {'x1': ..., 'y1': ..., 'x2': ..., 'y2': ...}
            door_num: Door number identifier
            region: Detection region as list or dict
            
        Returns:
            bool: True if logging successful, False otherwise
        """
        session = None
        try:
            # Set default timestamp if not provided
            if timestamp is None:
                timestamp = datetime.now()
            
            # Parse bbox (handles both list and dict formats)
            face_x1, face_y1, face_x2, face_y2 = _parse_bbox(face_bbox)
            
            # Parse region (handles both list and dict formats)
            region_x1, region_y1, region_x2, region_y2 = _parse_region(region)
            
            session = self.get_session()
            
            # Create log entry with parsed values
            log_entry = RecognitionLog(
                recognized_person=recognized_person,
                identity_verified=identity_verified,
                cosine_similarity=cosine_similarity,
                timestamp=timestamp,
                image_path=image_path,
                image_filename=os.path.basename(image_path) if image_path else None,
                face_x1=face_x1,
                face_y1=face_y1,
                face_x2=face_x2,
                face_y2=face_y2,
                door_num=door_num,
                region_x1=region_x1,
                region_y1=region_y1,
                region_x2=region_x2,
                region_y2=region_y2
            )
            session.add(log_entry)
            session.commit()
            logger.info(f"✓ Logged recognition: {recognized_person} at {timestamp} (similarity: {cosine_similarity})")
            return True
        except Exception as e:
            if session:
                session.rollback()
            logger.error(f"✗ Error logging recognition: {e}", exc_info=True)
            return False
        finally:
            if session:
                session.close()
    
    def save_config_snapshot(self, config: Dict, service_start_id: Optional[str] = None) -> Optional[int]:
        """Save a configuration snapshot."""
        session = None
        try:
            session = self.get_session()
            snapshot = ConfigSnapshot(
                config_json=json.dumps(config),
                service_start_id=service_start_id
            )
            session.add(snapshot)
            session.commit()
            return snapshot.id
        except Exception as e:
            if session:
                session.rollback()
            logger.error(f"Error saving config snapshot: {e}")
            return None
        finally:
            if session:
                session.close()
    
    def get_recognition_logs(
        self,
        limit: int = 100,
        offset: int = 0,
        person_name: Optional[str] = None,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> List[Dict]:
        """Get recognition logs with optional filters."""
        session = None
        try:
            session = self.get_session()
            query = session.query(RecognitionLog).order_by(RecognitionLog.timestamp.desc())
            
            if person_name:
                query = query.filter(RecognitionLog.recognized_person.ilike(f"%{person_name}%"))
            if start_date:
                query = query.filter(RecognitionLog.timestamp >= start_date)
            if end_date:
                query = query.filter(RecognitionLog.timestamp <= end_date)
            
            logs = query.offset(offset).limit(limit).all()
            
            return [
                {
                    'id': log.id,
                    'person_name': log.recognized_person,
                    'confidence': log.cosine_similarity,
                    'verified': log.identity_verified,
                    'timestamp': log.timestamp.isoformat() if log.timestamp else None,
                    'image_path': log.image_path,
                    'door_num': log.door_num
                }
                for log in logs
            ]
        except Exception as e:
            logger.error(f"Error getting recognition logs: {e}")
            return []
        finally:
            if session:
                session.close()
    
    def get_recognition_stats(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None
    ) -> Dict:
        """Get recognition statistics."""
        session = None
        try:
            session = self.get_session()
            query = session.query(RecognitionLog)
            
            if start_date:
                query = query.filter(RecognitionLog.timestamp >= start_date)
            if end_date:
                query = query.filter(RecognitionLog.timestamp <= end_date)
            
            total = query.count()
            verified = query.filter(RecognitionLog.identity_verified == True).count()
            
            return {
                'total': total,
                'verified': verified,
                'unverified': total - verified
            }
        except Exception as e:
            logger.error(f"Error getting stats: {e}")
            return {'total': 0, 'verified': 0, 'unverified': 0}
        finally:
            if session:
                session.close()
    
    def get_config_snapshots(self, limit: int = 10) -> List[Dict]:
        """Get configuration snapshots."""
        session = None
        try:
            session = self.get_session()
            snapshots = session.query(ConfigSnapshot).order_by(
                ConfigSnapshot.created_at.desc()
            ).limit(limit).all()
            
            return [
                {
                    'id': s.id,
                    'config': json.loads(s.config_json),
                    'service_start_id': s.service_start_id,
                    'created_at': s.created_at.isoformat() if s.created_at else None
                }
                for s in snapshots
            ]
        except Exception as e:
            logger.error(f"Error getting config snapshots: {e}")
            return []
        finally:
            if session:
                session.close()


# === Global instance ===
db_manager = DatabaseManager()


# === Wrapper functions for backward compatibility ===
def log_recognition(
    recognized_person: str,
    identity_verified: bool,
    cosine_similarity: float = None,
    timestamp: datetime = None,
    image_path: Optional[str] = None,
    face_bbox = None,
    door_num: Optional[int] = None,
    region = None
) -> bool:
    """
    Log a face recognition event (wrapper function).
    
    This function provides backward compatibility and convenience by wrapping
    the DatabaseManager.log_recognition method.
    """
    if not db_manager._initialized:
        db_manager.initialize()
    return db_manager.log_recognition(
        recognized_person=recognized_person,
        identity_verified=identity_verified,
        cosine_similarity=cosine_similarity,
        timestamp=timestamp,
        image_path=image_path,
        face_bbox=face_bbox,
        door_num=door_num,
        region=region
    )


def save_config_snapshot(config: Dict, service_start_id: Optional[str] = None) -> Optional[int]:
    """Save a configuration snapshot."""
    if not db_manager._initialized:
        db_manager.initialize()
    return db_manager.save_config_snapshot(config, service_start_id)


def get_recognition_logs(**kwargs) -> List[Dict]:
    """Get recognition logs with optional filters."""
    if not db_manager._initialized:
        db_manager.initialize()
    return db_manager.get_recognition_logs(**kwargs)


def get_recognition_stats(**kwargs) -> Dict:
    """Get recognition statistics."""
    if not db_manager._initialized:
        db_manager.initialize()
    return db_manager.get_recognition_stats(**kwargs)


def get_config_snapshots(**kwargs) -> List[Dict]:
    """Get configuration snapshots."""
    if not db_manager._initialized:
        db_manager.initialize()
    return db_manager.get_config_snapshots(**kwargs)
