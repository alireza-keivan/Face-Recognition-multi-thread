#!/usr/bin/env python3
"""
Initialize the users table in the database
"""
import sys
sys.path.insert(0, '/home/face/Face-Recognition-multi-thread/webapp')

from database import db_manager, Base, User
from sqlalchemy import inspect

def init_users_table():
    """Initialize the users table if it doesn't exist"""
    try:
        # Initialize database connection
        db_manager.initialize()
        
        # Check if users table exists
        inspector = inspect(db_manager.engine)
        if 'users' not in inspector.get_table_names():
            print("Creating users table...")
            Base.metadata.create_all(db_manager.engine)
            print("✓ Users table created successfully!")
        else:
            print("ℹ Users table already exists")
        
        # Check if there are any users
        session = db_manager.get_session()
        user_count = session.query(User).count()
        print(f"Current users in database: {user_count}")
        
        if user_count == 0:
            print("\nNo users found. You can create a user by:")
            print("1. Going to http://192.168.45.235:5000/register")
            print("2. Or running this script with --create-admin flag")
        
        session.close()
        return True
        
    except Exception as e:
        print(f"✗ Error initializing users table: {e}")
        import traceback
        traceback.print_exc()
        return False

def create_admin_user():
    """Create a default admin user"""
    try:
        session = db_manager.get_session()
        
        # Check if admin already exists
        existing_admin = session.query(User).filter_by(username='admin').first()
        if existing_admin:
            # Update existing admin to ensure is_admin flag is set
            if not existing_admin.is_admin:
                existing_admin.is_admin = True
                session.commit()
                print("✓ Updated existing admin user with admin privileges!")
            else:
                print("⚠ Admin user already exists with admin privileges!")
            session.close()
            return True
        
        # Create admin user
        admin = User(username='admin', email='admin@localhost', is_admin=True)
        admin.set_password('admin123')  # Change this password after first login!
        session.add(admin)
        session.commit()
        session.close()
        
        print("✓ Admin user created successfully!")
        print("  Username: admin")
        print("  Password: admin123")
        print("  ⚠ IMPORTANT: Change this password immediately after logging in!")
        return True
        
    except Exception as e:
        print(f"✗ Error creating admin user: {e}")
        return False

if __name__ == '__main__':
    print("=" * 50)
    print("Face Recognition System - User Authentication Setup")
    print("=" * 50)
    print()
    
    # Initialize table
    if init_users_table():
        print()
        
        # Check for --create-admin flag
        if '--create-admin' in sys.argv:
            print("Creating default admin user...")
            create_admin_user()
        else:
            print("Tip: Run with --create-admin to create a default admin user")
    
    print()
    print("=" * 50)
    print("Setup complete!")
    print("=" * 50)
