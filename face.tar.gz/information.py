import psutil
import socket
import platform
import uuid
import datetime
def get_system_info():

    l = []
    try:
        uptime_seconds = psutil.boot_time()
        uptime_dt = datetime.datetime.fromtimestamp(uptime_seconds)
        now_dt = datetime.datetime.now()
        uptime_delta = now_dt - uptime_dt
        printed_uptime = f"{uptime_delta}"
        l.append(printed_uptime)
    except AttributeError:
        print("Uptime: Not available on this system.")

    try:
        cpu_model = platform.processor()
        printed_cpu_model = cpu_model
        l.append(printed_cpu_model)
    except Exception:
        print("CPU Model: Not available.")
        
    cores = psutil.cpu_count(logical=True)
    printed_cores = cores
    l.append(printed_cores)
    # RAM Usage
    ram = psutil.virtual_memory()
    printed_ram = f"{ram.total / (1024**3):.2f} GB"
    printed_usage_ram = f"{ram.used / (1024**3):.2f} GB"
    l.append(printed_ram)
    l.append(printed_usage_ram)
    # Hard Disk Usage (for the root partition)
    partitions = psutil.disk_partitions()
    for p in partitions:
        usage = psutil.disk_usage(p.mountpoint)
        #print(f"\n--- Disk Usage on {p.mountpoint} ---")
        #print(f"Total Disk: {usage.total / (1024**3):.2f} GB")
        printed_usage_disk = f"Size: {usage.used / (1024**3):.2f}% GB, Percentage: {usage.percent:.1f}%"
    l.append(printed_usage_disk)
    return l

# =========================================================================
# NETWORK INFORMATION
# =========================================================================
import socket
import uuid

def get_network_info():
    info = []

    # MAC Address
    mac = ':'.join(['{:02x}'.format((uuid.getnode() >> ele) & 0xff) for ele in range(0,8*6,8)][::-1])
    info.append(f"{mac}")

    # IP Address
    try:
        #hostname = socket.gethostname()
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        #print(s.getsockname()[0])
        ip_address = socket.gethostbyname(s.getsockname()[0])
        info.append(f"{ip_address}")


    except socket.error as e:
        info.append(f"IP Address: Not connected or unavailable ({e})")
        
    return info

# Example usage:
# print(get_network_info())
# =========================================================================
# PROCESS-SPECIFIC INFORMATION
# =========================================================================
# =========================================================================
# PROCESS-SPECIFIC INFORMATION
# =========================================================================
def get_process_info(pid=None):
    if pid is None:
        pid = psutil.Process().pid
    
    info = []
    
    try:
        process = psutil.Process(pid)
        info.append(f"{pid}")

        # Get process uptime
        create_time = process.create_time()
        now_time = datetime.datetime.now().timestamp()
        uptime_seconds = now_time - create_time
        uptime_delta = datetime.timedelta(seconds=uptime_seconds)
        info.append(f"{uptime_delta}")

        # CPU & RAM usage
        info.append(f"{process.cpu_percent(interval=1)}%")

        mem = process.memory_info()
        info.append(f"{mem.rss / (1024**2):.2f} MB")

    except psutil.NoSuchProcess:
        info.append(f"Error: No process with PID {pid} was found.")
    except Exception as e:
        info.append(f"An error occurred: {e}")

    return info
