#!/usr/bin/env python3
"""
Test script to verify database.py fixes
Tests both list and dict bbox formats, and optional timestamp parameter
"""

import sys
import os
from datetime import datetime

# Add webapp to path
WEBAPP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'webapp')
sys.path.insert(0, WEBAPP_DIR)

from webapp.database import DatabaseManager

def test_database():
    """Test database logging functionality"""
    
    print("=" * 60)
    print("Testing Database Fixes")
    print("=" * 60)
    
    # Initialize database
    db = DatabaseManager()
    success = db.initialize()
    
    if not success:
        print("❌ Database initialization failed!")
        return False
    
    print("✓ Database initialized successfully")
    print()
    
    # Test 1: Log with list bbox (like thread.py does)
    print("Test 1: Logging with list bbox format...")
    result1 = db.log_recognition(
        recognized_person="Test Person 1",
        identity_verified=True,
        cosine_similarity=0.85,
        face_bbox=[100, 150, 300, 350],  # List format
        door_num=1,
        image_path="/home/face/Face-Recognition-multi-thread/saved_faces/test1.jpg"
        # Note: timestamp NOT provided (should default to now)
    )
    print(f"  Result: {'✓ SUCCESS' if result1 else '✗ FAILED'}")
    print()
    
    # Test 2: Log with dict bbox format
    print("Test 2: Logging with dict bbox format...")
    result2 = db.log_recognition(
        recognized_person="Test Person 2",
        identity_verified=False,
        cosine_similarity=0.65,
        face_bbox={'x1': 200, 'y1': 250, 'x2': 400, 'y2': 450},  # Dict format
        door_num=2,
        image_path="/home/face/Face-Recognition-multi-thread/saved_faces/test2.jpg",
        timestamp=datetime.now()
    )
    print(f"  Result: {'✓ SUCCESS' if result2 else '✗ FAILED'}")
    print()
    
    # Test 3: Log without bbox (should handle None)
    print("Test 3: Logging without bbox...")
    result3 = db.log_recognition(
        recognized_person="Test Person 3",
        identity_verified=True,
        cosine_similarity=0.92,
        door_num=1,
        image_path="/home/face/Face-Recognition-multi-thread/saved_faces/test3.jpg"
        # No bbox, no timestamp
    )
    print(f"  Result: {'✓ SUCCESS' if result3 else '✗ FAILED'}")
    print()
    
    # Test 4: Minimal parameters (like thread.py first call)
    print("Test 4: Minimal parameters (matching thread.py usage)...")
    result4 = db.log_recognition(
        recognized_person="John Doe",
        cosine_similarity=0.78,
        identity_verified=True,
        face_bbox=[50, 75, 200, 225],
        door_num=1,
        image_path="/home/face/Face-Recognition-multi-thread/saved_faces/john_doe.jpg"
    )
    print(f"  Result: {'✓ SUCCESS' if result4 else '✗ FAILED'}")
    print()
    
    # Summary
    print("=" * 60)
    all_passed = all([result1, result2, result3, result4])
    if all_passed:
        print("✓ ALL TESTS PASSED!")
        print("Database is ready to receive logs from thread.py")
    else:
        print("✗ SOME TESTS FAILED")
        print("Check the error messages above")
    print("=" * 60)
    
    return all_passed


if __name__ == "__main__":
    try:
        success = test_database()
        sys.exit(0 if success else 1)
    except Exception as e:
        print(f"\n❌ Test script error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
