// Common utility functions and global state

// Global state
let serviceCheckInterval = null;

// Show notification
function showNotification(message, type = 'success') {
    const notification = document.getElementById('notification');
    if (!notification) return;
    
    notification.textContent = message;
    notification.className = `notification ${type}`;
    notification.style.display = 'block';
    
    setTimeout(() => {
        notification.style.display = 'none';
    }, 5000);
}

// Show loading overlay
function showLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.display = 'flex';
    }
}

// Hide loading overlay
function hideLoading() {
    const overlay = document.getElementById('loadingOverlay');
    if (overlay) {
        overlay.style.display = 'none';
    }
}

// Check service status
async function checkServiceStatus() {
    try {
        const response = await fetch('/api/service/status');
        const data = await response.json();
        
        if (data.success) {
            updateServiceStatus(data.status);
        }
    } catch (error) {
        console.error('Error checking service status:', error);
    }
}

// Update service status in navbar
function updateServiceStatus(status) {
    const statusText = document.getElementById('serviceStatusText');
    const statusIndicator = document.getElementById('serviceStatusIndicator');
    
    if (statusText && statusIndicator) {
        if (status.running) {
            statusText.textContent = 'Running';
            statusIndicator.className = 'status-indicator running';
        } else {
            statusText.textContent = 'Stopped';
            statusIndicator.className = 'status-indicator stopped';
        }
    }
}

// Initialize common functionality
document.addEventListener('DOMContentLoaded', () => {
    // Check service status immediately
    checkServiceStatus();
    
    // Start periodic status check (every 10 seconds)
    serviceCheckInterval = setInterval(checkServiceStatus, 10000);
    
    // Highlight active nav link
    const currentPath = window.location.pathname;
    document.querySelectorAll('.nav-link').forEach(link => {
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });
});

// Clean up on page unload
window.addEventListener('beforeunload', () => {
    if (serviceCheckInterval) {
        clearInterval(serviceCheckInterval);
    }
});

// API helper function
async function apiRequest(url, options = {}) {
    try {
        showLoading();
        const response = await fetch(url, {
            headers: {
                'Content-Type': 'application/json',
                ...options.headers
            },
            ...options
        });
        
        const data = await response.json();
        hideLoading();
        
        if (!response.ok) {
            throw new Error(data.message || 'Request failed');
        }
        
        return data;
    } catch (error) {
        hideLoading();
        throw error;
    }
}

// Format file size
function formatFileSize(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

// Confirm dialog helper
function confirmAction(message) {
    return confirm(message);
}
