// static/js/config.js - Configuration page functionality

let currentConfig = {};

// Tab switching
function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });

    // Show selected tab
    document.getElementById(tabName).classList.add('active');
    document.querySelector(`[onclick="showTab('${tabName}')"]`).classList.add('active');
}

// Load configuration into form
async function loadConfigForm() {
    try {
        const response = await apiRequest('/api/config');
        if (response.success) {
            currentConfig = response.config;
            populateForm(currentConfig);
            updateRawEditor();
        }
    } catch (error) {
        showNotification('Failed to load configuration', 'error');
    }
}

// Populate form fields from config object
function populateForm(config) {
    // Camera settings
    setFormValue('camera_settings.SOURCE', config.camera_settings?.SOURCE);
    setFormValue('camera_settings.WINDOW_WIDTH', config.camera_settings?.WINDOW_WIDTH);
    setFormValue('camera_settings.WINDOW_HEIGHT', config.camera_settings?.WINDOW_HEIGHT);
    setFormValue('camera_settings.fps_limit', config.camera_settings?.fps_limit);
    setFormValue('camera_settings.resize_scale', config.camera_settings?.resize_scale);

    // Face recognition settings
    setFormValue('face_recognition_settings.PROCESS_FRAME_SCALE', config.face_recognition_settings?.PROCESS_FRAME_SCALE);
    setFormValue('face_recognition_settings.RECOGNITION_TOLERANCE', config.face_recognition_settings?.RECOGNITION_TOLERANCE);
    setFormValue('face_recognition_settings.COSINE_SIMILARITY_THRESHOLD', config.face_recognition_settings?.COSINE_SIMILARITY_THRESHOLD);
    setFormValue('face_recognition_settings.detection_width', config.face_recognition_settings?.detection_width);
    setFormValue('face_recognition_settings.detection_height', config.face_recognition_settings?.detection_height);
    setFormValue('face_recognition_settings.detection_interval_seconds', config.face_recognition_settings?.detection_interval_seconds);

    // Directories
    setFormValue('directories.CAPTURED_KNOWN_FACES_DIR', config.directories?.CAPTURED_KNOWN_FACES_DIR);
    setFormValue('directories.FACE_DATABASE_DIR', config.directories?.FACE_DATABASE_DIR);
    setFormValue('directories.UNKNOWN_FACES_PHOTOS_DIR', config.directories?.UNKNOWN_FACES_PHOTOS_DIR);

    // MQTT settings
    setFormValue('mqtt_settings.MQTT_BROKER_IP', config.mqtt_settings?.MQTT_BROKER_IP);
    setFormValue('mqtt_settings.MQTT_BROKER_PORT', config.mqtt_settings?.MQTT_BROKER_PORT);
    setFormValue('mqtt_settings.DOOR_OPEN_COOLDOWN', config.mqtt_settings?.DOOR_OPEN_COOLDOWN);
    setFormValue('mqtt_settings.RESET_DOOR_TIMER', config.mqtt_settings?.RESET_DOOR_TIMER);
    setFormValue('mqtt_settings.IMAGE_SEND_COOLDOWN', config.mqtt_settings?.IMAGE_SEND_COOLDOWN);

    // Operation region
    setFormValue('operation_region.x1', config.operation_region?.x1);
    setFormValue('operation_region.x2', config.operation_region?.x2);
    setFormValue('operation_region.y1', config.operation_region?.y1);
    setFormValue('operation_region.y2', config.operation_region?.y2);
    setFormValue('operation_region.door_num', config.operation_region?.door_num);

    // OpenVINO settings
    setFormValue('openvino_settings.DEVICE', config.openvino_settings?.DEVICE);
}

// Helper to set form value
function setFormValue(name, value) {
    const element = document.querySelector(`[name="${name}"]`);
    if (element && value !== undefined) {
        element.value = value;
    }
}

// Update raw JSON editor
function updateRawEditor() {
    const editor = document.getElementById('rawConfigEditor');
    if (editor) {
        editor.value = JSON.stringify(currentConfig, null, 4);
    }
}

// Save configuration from form
async function saveConfig(event) {
    event.preventDefault();
    showLoading('Saving configuration...');

    try {
        const formData = new FormData(event.target);
        const response = await fetch('/api/config', {
            method: 'POST',
            body: formData
        });

        const result = await response.json();
        hideLoading();

        if (result.success) {
            showNotification('Configuration saved and service restarted!', 'success');
            await loadConfigForm();
        } else {
            showNotification(result.message || 'Failed to save configuration', 'error');
        }
    } catch (error) {
        hideLoading();
        showNotification('Error saving configuration', 'error');
    }
}

// Save raw JSON configuration
async function saveRawConfig() {
    showLoading('Saving configuration...');

    try {
        const editor = document.getElementById('rawConfigEditor');
        const configText = editor.value;

        // Validate JSON
        JSON.parse(configText);

        const response = await apiRequest('/api/config/raw', {
            method: 'POST',
            body: JSON.stringify({ config: configText })
        });

        hideLoading();

        if (response.success) {
            showNotification('Configuration saved and service restarted!', 'success');
            await loadConfigForm();
        } else {
            showNotification(response.message || 'Failed to save', 'error');
        }
    } catch (error) {
        hideLoading();
        if (error instanceof SyntaxError) {
            showNotification('Invalid JSON format', 'error');
        } else {
            showNotification('Error saving configuration', 'error');
        }
    }
}

// Load exit script
async function loadExitScript() {
    try {
        const response = await apiRequest('/api/exit');
        if (response.success) {
            document.getElementById('exitScriptEditor').value = response.content;
        }
    } catch (error) {
        showNotification('Failed to load exit script', 'error');
    }
}

// Save exit script
async function saveExitScript() {
    showLoading('Saving exit script...');

    try {
        const content = document.getElementById('exitScriptEditor').value;
        const response = await apiRequest('/api/exit', {
            method: 'POST',
            body: JSON.stringify({ content })
        });

        hideLoading();

        if (response.success) {
            showNotification('Exit script saved and service restarted!', 'success');
        } else {
            showNotification(response.message || 'Failed to save', 'error');
        }
    } catch (error) {
        hideLoading();
        showNotification('Error saving exit script', 'error');
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', () => {
    loadConfigForm();
    loadExitScript();
});
