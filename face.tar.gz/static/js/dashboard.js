
let autoRefreshInterval = null;
let isAutoRefreshEnabled = false;

// =============================================================================
// Service Management Functions
// =============================================================================

async function startService() {
    if (!confirmAction('Start the face recognition service?')) {
        return;
    }
    try {
        const data = await apiRequest('/api/service/start', { method: 'POST' });
        if (data.success) {
            showNotification(data.message, 'success');
            await checkServiceStatus();
        } else {
            showNotification(data.message || 'Failed to start service', 'error');
        }
    } catch (error) {
        showNotification('Error starting service: ' + error.message, 'error');
    }
}

async function restartService() {
    if (!confirmAction('Restart the face recognition service?')) {
        return;
    }
    try {
        const data = await apiRequest('/api/service/restart', { method: 'POST' });
        if (data.success) {
            showNotification(data.message, 'success');
            await checkServiceStatus();
        } else {
            showNotification(data.message || 'Failed to restart service', 'error');
        }
    } catch (error) {
        showNotification('Error restarting service: ' + error.message, 'error');
    }
}

async function stopService() {
    if (!confirmAction('Stop the face recognition service?')) {
        return;
    }
    try {
        const data = await apiRequest('/api/service/stop', { method: 'POST' });
        if (data.success) {
            showNotification(data.message, 'warning');
            await checkServiceStatus();
        } else {
            showNotification(data.message || 'Failed to stop service', 'error');
        }
    } catch (error) {
        showNotification('Error stopping service: ' + error.message, 'error');
    }
}

// =============================================================================
// Database Health Check
// =============================================================================

async function checkDatabaseHealth() {
    const indicator = document.getElementById('dbStatusIndicator');
    const text = document.getElementById('dbStatusText');
    
    if (!indicator || !text) {
        console.warn('Database status elements not found');
        return;
    }
    
    try {
        const response = await fetch('/api/db/health');
        const data = await response.json();
        
        if (data.connected) {
            indicator.className = 'status-indicator status-connected';
            indicator.style.backgroundColor = '#28a745';
            text.textContent = 'Connected';
            text.style.color = '#28a745';
        } else {
            indicator.className = 'status-indicator status-disconnected';
            indicator.style.backgroundColor = '#dc3545';
            text.textContent = 'Disconnected';
            text.style.color = '#dc3545';
        }
    } catch (error) {
        console.error('Database health check failed:', error);
        indicator.className = 'status-indicator status-error';
        indicator.style.backgroundColor = '#dc3545';
        text.textContent = 'Error';
        text.style.color = '#dc3545';
    }
}

// =============================================================================
// Statistics Loading
// =============================================================================

async function loadStatistics() {
    const hoursSelect = document.getElementById('statsHours');
    const hours = hoursSelect ? parseInt(hoursSelect.value) : 24;
    
    try {
        const response = await fetch(`/api/db/stats?hours=${hours}`);
        const data = await response.json();
        
        if (data.success) {
            const stats = data.stats;
            
            // Update main stat cards (top row)
            updateElement('statTotalRecognitions', stats.total_recognitions || 0);
            updateElement('statVerifiedCount', stats.verified_count || 0);
            updateElement('statUnknownCount', stats.unknown_count || 0);
            updateElement('statUniquePersons', stats.unique_persons || 0);
            
            // Update database dashboard stats
            const verificationRate = stats.total_recognitions > 0 
                ? ((stats.verified_count / stats.total_recognitions) * 100).toFixed(1) + '%'
                : '0%';
            updateElement('statVerificationRate', verificationRate);
            
            const avgConfidence = stats.avg_confidence 
                ? (stats.avg_confidence * 100).toFixed(1) + '%'
                : '-';
            updateElement('statAvgConfidence', avgConfidence);
        }
    } catch (error) {
        console.error('Failed to load statistics:', error);
    }
}

function updateElement(id, value) {
    const el = document.getElementById(id);
    if (el) {
        el.textContent = value;
    }
}

// =============================================================================
// Recent Activity Loading
// =============================================================================

async function loadRecentActivity() {
    const minutesSelect = document.getElementById('recentMinutes');
    const minutes = minutesSelect ? parseInt(minutesSelect.value) : 60;
    const tbody = document.getElementById('recentActivityBody');
    
    if (!tbody) {
        console.warn('recentActivityBody element not found');
        return;
    }
    
    tbody.innerHTML = '<tr><td colspan="5" class="text-center">Loading...</td></tr>';
    
    try {
        const response = await fetch(`/api/db/logs/recent?minutes=${minutes}`);
        const data = await response.json();
        
        if (data.success && data.logs && data.logs.length > 0) {
            tbody.innerHTML = data.logs.map(log => `
                <tr>
                    <td>${formatTime(log.timestamp)}</td>
                    <td>${escapeHtml(log.person_name || 'Unknown')}</td>
                    <td>
                        <span class="badge ${log.verified ? 'badge-success' : 'badge-warning'}">
                            ${log.verified ? '✅ Verified' : '❓ Unknown'}
                        </span>
                    </td>
                    <td>${log.confidence ? (log.confidence * 100).toFixed(1) + '%' : '-'}</td>
                    <td>${log.door_num || '-'}</td>
                </tr>
            `).join('');
        } else {
            tbody.innerHTML = '<tr><td colspan="5" class="text-center text-muted">No recent activity</td></tr>';
        }
    } catch (error) {
        console.error('Failed to load recent activity:', error);
        tbody.innerHTML = '<tr><td colspan="5" class="text-center text-danger">Error loading data</td></tr>';
    }
}

// =============================================================================
// Persons Summary Loading
// =============================================================================

async function loadPersonsSummary() {
    const container = document.getElementById('personsSummary');
    
    if (!container) {
        console.warn('personsSummary element not found');
        return;
    }
    
    container.innerHTML = '<p class="text-center">Loading...</p>';
    
    try {
        const response = await fetch('/api/db/persons');
        const data = await response.json();
        
        if (data.success && data.persons && data.persons.length > 0) {
            container.innerHTML = data.persons.map(person => `
                <div class="person-card">
                    <div class="person-avatar">
                        ${person.person_name ? person.person_name.charAt(0).toUpperCase() : '?'}
                    </div>
                    <div class="person-info">
                        <h5>${escapeHtml(person.person_name || 'Unknown')}</h5>
                        <p>Recognitions: ${person.count || 0}</p>
                        <p class="text-muted">Last seen: ${formatTime(person.last_seen)}</p>
                    </div>
                </div>
            `).join('');
        } else {
            container.innerHTML = '<p class="text-center text-muted">No persons found</p>';
        }
    } catch (error) {
        console.error('Failed to load persons summary:', error);
        container.innerHTML = '<p class="text-center text-danger">Error loading data</p>';
    }
}

// =============================================================================
// Full Logs Loading
// =============================================================================

async function loadFullLogs() {
    const tbody = document.getElementById('logsTableBody');
    const countBadge = document.getElementById('logsCount');
    
    // Get filter values
    const personFilter = document.getElementById('filterPerson')?.value || '';
    const statusFilter = document.getElementById('filterStatus')?.value || '';
    
    if (tbody) {
        tbody.innerHTML = '<tr><td colspan="6" class="text-center">Loading...</td></tr>';
    }
    
    try {
        let url = '/api/db/logs?limit=200';
        if (personFilter) url += `&person=${encodeURIComponent(personFilter)}`;
        if (statusFilter) url += `&status=${statusFilter}`;
        
        const response = await fetch(url);
        const data = await response.json();
        
        if (countBadge) {
            countBadge.textContent = data.logs ? data.logs.length : 0;
        }
        
        if (tbody && data.success && data.logs && data.logs.length > 0) {
            tbody.innerHTML = data.logs.map(log => `
                <tr>
                    <td>${log.id || '-'}</td>
                    <td>${formatDateTime(log.timestamp)}</td>
                    <td>${escapeHtml(log.person_name || 'Unknown')}</td>
                    <td>
                        <span class="badge ${log.verified ? 'badge-success' : 'badge-warning'}">
                            ${log.verified ? 'Verified' : 'Unknown'}
                        </span>
                    </td>
                    <td>${log.confidence ? (log.confidence * 100).toFixed(1) + '%' : '-'}</td>
                    <td>${log.door_num || '-'}</td>
                </tr>
            `).join('');
        } else if (tbody) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted">No logs found</td></tr>';
        }
    } catch (error) {
        console.error('Failed to load logs:', error);
        if (tbody) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-danger">Error loading logs</td></tr>';
        }
    }
}

// =============================================================================
// Config Snapshots Loading
// =============================================================================

async function loadConfigSnapshots() {
    const tbody = document.getElementById('snapshotsBody');
    
    if (!tbody) {
        console.warn('snapshotsBody element not found');
        return;
    }
    
    tbody.innerHTML = '<tr><td colspan="4" class="text-center">Loading...</td></tr>';
    
    try {
        const response = await fetch('/api/db/config-snapshots');
        const data = await response.json();
        
        if (data.success && data.snapshots && data.snapshots.length > 0) {
            tbody.innerHTML = data.snapshots.map(snap => `
                <tr>
                    <td>${snap.id}</td>
                    <td>${formatDateTime(snap.created_at)}</td>
                    <td>${escapeHtml(snap.description || '-')}</td>
                    <td>
                        <button class="btn btn-sm btn-primary" onclick="viewSnapshot(${snap.id})">
                            👁️ View
                        </button>
                        <button class="btn btn-sm btn-warning" onclick="restoreSnapshot(${snap.id})">
                            ↩️ Restore
                        </button>
                    </td>
                </tr>
            `).join('');
        } else {
            tbody.innerHTML = '<tr><td colspan="4" class="text-center text-muted">No snapshots found</td></tr>';
        }
    } catch (error) {
        console.error('Failed to load snapshots:', error);
        tbody.innerHTML = '<tr><td colspan="4" class="text-center text-danger">Error loading snapshots</td></tr>';
    }
}

async function viewSnapshot(id) {
    try {
        const response = await fetch(`/api/db/config-snapshots/${id}`);
        const data = await response.json();
        
        if (data.success) {
            alert('Snapshot Config:\n\n' + JSON.stringify(data.snapshot.config_data, null, 2));
        }
    } catch (error) {
        showNotification('Error loading snapshot: ' + error.message, 'error');
    }
}

async function restoreSnapshot(id) {
    if (!confirmAction('Restore this configuration snapshot? Current config will be overwritten.')) {
        return;
    }
    
    try {
        const response = await fetch(`/api/db/config-snapshots/${id}`);
        const data = await response.json();
        
        if (data.success && data.snapshot) {
            const saveResponse = await fetch('/api/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(data.snapshot.config_data)
            });
            
            const saveData = await saveResponse.json();
            if (saveData.success) {
                showNotification('Configuration restored successfully!', 'success');
            } else {
                showNotification('Failed to restore: ' + saveData.message, 'error');
            }
        }
    } catch (error) {
        showNotification('Error restoring snapshot: ' + error.message, 'error');
    }
}

async function createSnapshot() {
    const description = prompt('Enter a description for this snapshot:');
    if (description === null) return;
    
    try {
        const response = await fetch('/api/db/config-snapshots', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ description: description })
        });
        
        const data = await response.json();
        if (data.success) {
            showNotification('Snapshot created successfully!', 'success');
            loadConfigSnapshots();
        } else {
            showNotification('Failed to create snapshot: ' + data.message, 'error');
        }
    } catch (error) {
        showNotification('Error creating snapshot: ' + error.message, 'error');
    }
}

// =============================================================================
// Refresh All Data
// =============================================================================

async function refreshAllData() {
    console.log('Refreshing all dashboard data...');
    
    await Promise.all([
        checkDatabaseHealth(),
        loadStatistics(),
        loadRecentActivity()
    ]);
    
    // Load tab-specific data based on active tab
    const activeTab = document.querySelector('.db-tab-btn.active');
    if (activeTab) {
        const tabName = activeTab.getAttribute('data-tab');
        switch(tabName) {
            case 'persons':
                await loadPersonsSummary();
                break;
            case 'logs':
                await loadFullLogs();
                break;
            case 'snapshots':
                await loadConfigSnapshots();
                break;
        }
    }
    
    console.log('Dashboard refresh complete');
}

// =============================================================================
// Auto Refresh Toggle
// =============================================================================

function toggleAutoRefresh() {
    const btn = document.getElementById('autoRefreshToggle');
    
    if (isAutoRefreshEnabled) {
        // Stop auto refresh
        clearInterval(autoRefreshInterval);
        autoRefreshInterval = null;
        isAutoRefreshEnabled = false;
        if (btn) {
            btn.textContent = '▶️ Auto-Refresh';
            btn.classList.remove('btn-danger');
            btn.classList.add('btn-primary');
        }
        showNotification('Auto-refresh disabled', 'info');
    } else {
        // Start auto refresh (every 30 seconds)
        isAutoRefreshEnabled = true;
        autoRefreshInterval = setInterval(refreshAllData, 30000);
        if (btn) {
            btn.textContent = '⏹️ Stop Refresh';
            btn.classList.remove('btn-primary');
            btn.classList.add('btn-danger');
        }
        showNotification('Auto-refresh enabled (30s interval)', 'success');
    }
}

// =============================================================================
// Tab Switching
// =============================================================================

function initializeTabs() {
    const tabButtons = document.querySelectorAll('.db-tab-btn');
    
    tabButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const tabName = this.getAttribute('data-tab');
            switchTab(tabName);
        });
    });
}

function switchTab(tabName) {
    // Update button states
    document.querySelectorAll('.db-tab-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.getAttribute('data-tab') === tabName) {
            btn.classList.add('active');
        }
    });
    
    // Update content visibility
    document.querySelectorAll('.db-tab-content').forEach(content => {
        content.style.display = 'none';
        content.classList.remove('active');
    });
    
    const activeContent = document.getElementById(`dbTab-${tabName}`);
    if (activeContent) {
        activeContent.style.display = 'block';
        activeContent.classList.add('active');
    }
    
    // Load data for the selected tab
    switch(tabName) {
        case 'overview':
            loadRecentActivity();
            break;
        case 'persons':
            loadPersonsSummary();
            break;
        case 'logs':
            loadFullLogs();
            break;
        case 'snapshots':
            loadConfigSnapshots();
            break;
    }
}

// =============================================================================
// Filter Event Listeners
// =============================================================================

function initializeFilters() {
    // Stats hours filter
    const statsHours = document.getElementById('statsHours');
    if (statsHours) {
        statsHours.addEventListener('change', loadStatistics);
    }
    
    // Recent minutes filter
    const recentMinutes = document.getElementById('recentMinutes');
    if (recentMinutes) {
        recentMinutes.addEventListener('change', loadRecentActivity);
    }
    
    // Person filter (with debounce)
    const filterPerson = document.getElementById('filterPerson');
    if (filterPerson) {
        let debounceTimer;
        filterPerson.addEventListener('input', () => {
            clearTimeout(debounceTimer);
            debounceTimer = setTimeout(loadFullLogs, 500);
        });
    }
    
    // Status filter
    const filterStatus = document.getElementById('filterStatus');
    if (filterStatus) {
        filterStatus.addEventListener('change', loadFullLogs);
    }
}

// =============================================================================
// Utility Functions
// =============================================================================

function formatTime(timestamp) {
    if (!timestamp) return '-';
    try {
        const date = new Date(timestamp);
        return date.toLocaleTimeString('en-US', { 
            hour: '2-digit', 
            minute: '2-digit',
            second: '2-digit'
        });
    } catch (e) {
        return timestamp;
    }
}

function formatDateTime(timestamp) {
    if (!timestamp) return '-';
    try {
        const date = new Date(timestamp);
        return date.toLocaleString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    } catch (e) {
        return timestamp;
    }
}

function escapeHtml(text) {
    if (!text) return '';
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// =============================================================================
// Initialization
// =============================================================================

document.addEventListener('DOMContentLoaded', () => {
    console.log('Dashboard.js loaded - initializing...');
    
    // Check if we're on the dashboard page (has database section)
    const dbSection = document.getElementById('databaseSection');
    
    if (dbSection) {
        console.log('Database section found - initializing dashboard...');
        
        // Initialize components
        initializeTabs();
        initializeFilters();
        
        // Initial data load
        checkDatabaseHealth();
        loadStatistics();
        loadRecentActivity();
        
        console.log('Dashboard initialization complete!');
    } else {
        console.log('No database section found - skipping dashboard init');
    }
});

// =============================================================================
// Export functions for global access (onclick handlers)
// =============================================================================

window.refreshAllData = refreshAllData;
window.toggleAutoRefresh = toggleAutoRefresh;
window.loadPersonsSummary = loadPersonsSummary;
window.loadFullLogs = loadFullLogs;
window.loadConfigSnapshots = loadConfigSnapshots;
window.createSnapshot = createSnapshot;
window.viewSnapshot = viewSnapshot;
window.restoreSnapshot = restoreSnapshot;
window.startService = startService;
window.restartService = restartService;
window.stopService = stopService;
