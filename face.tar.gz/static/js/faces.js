// Faces management functionality

let selectedFiles = [];

// Initialize faces page
document.addEventListener('DOMContentLoaded', () => {
    const fileInput = document.getElementById('fileInput');
    const fileLabel = document.getElementById('fileLabel');
    
    if (fileInput) {
        fileInput.addEventListener('change', handleFileSelect);
    }
    
    // Load faces list
    loadFacesList();
});

// Handle file selection
function handleFileSelect(event) {
    const files = Array.from(event.target.files);
    selectedFiles = files;
    
    const fileLabel = document.getElementById('fileLabel');
    const fileList = document.getElementById('fileList');
    
    if (files.length > 0) {
        fileLabel.querySelector('span').textContent = `${files.length} file(s) selected`;
        displayFileList(files);
    } else {
        fileLabel.querySelector('span').textContent = 'Choose Files';
        fileList.innerHTML = '';
    }
}

// Display selected files
function displayFileList(files) {
    const fileList = document.getElementById('fileList');
    fileList.innerHTML = '';
    
    files.forEach((file, index) => {
        const fileItem = document.createElement('div');
        fileItem.className = 'file-item';
        fileItem.innerHTML = `
            <span>📄 ${file.name} (${formatFileSize(file.size)})</span>
            <button onclick="removeFile(${index})" class="delete-btn" style="padding: 0.25rem 0.5rem; font-size: 0.8rem;">Remove</button>
        `;
        fileList.appendChild(fileItem);
    });
}

// Remove file from selection
function removeFile(index) {
    const fileInput = document.getElementById('fileInput');
    const dt = new DataTransfer();
    
    selectedFiles = selectedFiles.filter((_, i) => i !== index);
    
    selectedFiles.forEach(file => dt.items.add(file));
    fileInput.files = dt.files;
    
    displayFileList(selectedFiles);
    
    if (selectedFiles.length === 0) {
        document.getElementById('fileLabel').querySelector('span').textContent = 'Choose Files';
        document.getElementById('fileList').innerHTML = '';
    }
}

// Upload faces
async function uploadFaces(event) {
    event.preventDefault();
    
    const fileInput = document.getElementById('fileInput');
    const personName = document.getElementById('personName').value.trim();
    
    if (!fileInput.files || fileInput.files.length === 0) {
        showNotification('Please select at least one file', 'warning');
        return;
    }
    
    const formData = new FormData();
    Array.from(fileInput.files).forEach(file => {
        formData.append('file', file);
    });
    
    if (personName) {
        formData.append('person_name', personName);
    }
    
    try {
        showLoading();
        const response = await fetch('/api/faces/upload', {
            method: 'POST',
            body: formData
        });
        
        const data = await response.json();
        hideLoading();
        
        if (data.success) {
            showNotification(data.message, 'success');
            
            // Reset form
            document.getElementById('uploadForm').reset();
            document.getElementById('fileLabel').querySelector('span').textContent = 'Choose Files';
            document.getElementById('fileList').innerHTML = '';
            selectedFiles = [];
            
            // Reload faces list
            await loadFacesList();
            
            // Show restart info
            if (data.restart) {
                setTimeout(() => {
                    showNotification('Service restarted to apply changes', 'success');
                }, 2000);
            }
        } else {
            showNotification(data.message || 'Upload failed', 'error');
            if (data.errors && data.errors.length > 0) {
                console.error('Upload errors:', data.errors);
            }
        }
    } catch (error) {
        hideLoading();
        showNotification('Error uploading files: ' + error.message, 'error');
    }
}

// Create folder
async function createFolder() {
    const folderName = document.getElementById('folderName').value.trim();
    
    if (!folderName) {
        showNotification('Please enter a folder name', 'warning');
        return;
    }
    
    try {
        const data = await apiRequest('/api/faces/folder', {
            method: 'POST',
            body: JSON.stringify({ folder_name: folderName })
        });
        
        if (data.success) {
            showNotification(data.message, 'success');
            document.getElementById('folderName').value = '';
            await loadFacesList();
        } else {
            showNotification(data.message || 'Failed to create folder', 'error');
        }
    } catch (error) {
        showNotification('Error creating folder: ' + error.message, 'error');
    }
}

// Load faces list
async function loadFacesList() {
    try {
        const data = await apiRequest('/api/faces');
        
        if (data.success) {
            displayFaces(data.faces);
        }
    } catch (error) {
        console.error('Error loading faces:', error);
        showNotification('Error loading faces list', 'error');
    }
}

// Display faces in grid
function displayFaces(faces) {
    const facesList = document.getElementById('facesList');
    
    if (!faces || faces.length === 0) {
        facesList.innerHTML = '<p style="text-align: center; color: var(--text-light); padding: 2rem;">No faces found. Upload some images to get started!</p>';
        return;
    }
    
    facesList.innerHTML = faces.map(face => {
        if (face.type === 'folder') {
            return `
                <div class="face-card">
                    <div class="face-card-header">
                        <h4>📁 ${face.name}</h4>
                        <span>${face.image_count} image(s)</span>
                    </div>
                    <div class="face-card-body">
                        ${face.images.length > 0 ? `
                            <div class="face-images">
                                ${face.images.slice(0, 4).map(img => `
                                    <img src="/faces/${encodeURIComponent(face.name)}/${encodeURIComponent(img.name)}" 
                                         alt="${img.name}"
                                         class="face-thumbnail"
                                         onclick="openModal('/faces/${encodeURIComponent(face.name)}/${encodeURIComponent(img.name)}', '${img.name}')">
                                `).join('')}
                                ${face.images.length > 4 ? `<div style="grid-column: span 2; text-align: center; padding: 1rem; color: var(--text-light);">+${face.images.length - 4} more</div>` : ''}
                            </div>
                        ` : '<p style="color: var(--text-light); text-align: center; padding: 1rem;">Empty folder</p>'}
                        <button onclick="deleteFace('${face.path}', 'folder')" class="delete-btn">Delete Folder</button>
                    </div>
                </div>
            `;
        } else {
            return `
                <div class="face-card">
                    <div class="face-card-header">
                        <h4>🖼️ ${face.name}</h4>
                        <span>${face.size_kb} KB</span>
                    </div>
                    <div class="face-card-body">
                        <div class="face-images">
                            <img src="/faces/${encodeURIComponent(face.name)}" 
                                 alt="${face.name}"
                                 class="face-thumbnail"
                                 onclick="openModal('/faces/${encodeURIComponent(face.name)}', '${face.name}')"
                                 style="grid-column: span 2;">
                        </div>
                        <button onclick="deleteFace('${face.path}', 'image')" class="delete-btn">Delete Image</button>
                    </div>
                </div>
            `;
        }
    }).join('');
}

// Delete face/folder
async function deleteFace(path, type) {
    const itemType = type === 'folder' ? 'folder and all its contents' : 'image';
    
    if (!confirmAction(`Are you sure you want to delete this ${itemType}?`)) {
        return;
    }
    
    try {
        const data = await apiRequest('/api/faces/delete', {
            method: 'POST',
            body: JSON.stringify({ path: path })
        });
        
        if (data.success) {
            showNotification(data.message, 'success');
            await loadFacesList();
        } else {
            showNotification(data.message || 'Failed to delete', 'error');
        }
    } catch (error) {
        showNotification('Error deleting: ' + error.message, 'error');
    }
}

// Open image modal
function openModal(imagePath, imageName) {
    const modal = document.getElementById('imageModal');
    const modalImg = document.getElementById('modalImage');
    const caption = document.getElementById('modalCaption');
    
    modal.style.display = 'block';
    modalImg.src = imagePath;
    caption.textContent = imageName;
}

// Close modal
function closeModal() {
    const modal = document.getElementById('imageModal');
    modal.style.display = 'none';
}

// Close modal on outside click
window.onclick = function(event) {
    const modal = document.getElementById('imageModal');
    if (event.target === modal) {
        modal.style.display = 'none';
    }
}
