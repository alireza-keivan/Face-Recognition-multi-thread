document.addEventListener("DOMContentLoaded", () => {

    // TAB SWITCHING
    const tabs = document.querySelectorAll(".tab-btn");
    const pages = document.querySelectorAll(".tab-page");

    tabs.forEach(btn => {
        btn.addEventListener("click", () => {
            tabs.forEach(t => t.classList.remove("active"));
            pages.forEach(p => p.classList.remove("active"));

            btn.classList.add("active");
            document.getElementById(btn.dataset.tab).classList.add("active");
        });
    });

    // Placeholder: Load config + faces later
    document.getElementById("camera-content").innerText = "Camera config will load here...";
    document.getElementById("fr-content").innerText = "Face recognition settings...";
    document.getElementById("mqtt-content").innerText = "MQTT settings...";
    document.getElementById("directories-content").innerText = "Directories list...";
    document.getElementById("opt-content").innerText = "Optimization settings...";
});
