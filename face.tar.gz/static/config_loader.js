// config_loader.js
// Dynamically fetch config.json via backend and populate all fields

async function loadConfig() {
  try {
    console.log("Loading configuration from /get_config...");
    const response = await fetch('/get_config');
    const config = await response.json();

    const cs = config.camera_settings || {};
    const fr = config.face_recognition_settings || {};
    const dr = config.directories || {};
    const mq = config.mqtt_settings || {};
    const opt = config.optimization_settings || {};

    // ---- Camera
    document.getElementById('camera_url').value = cs.url || "";
    document.getElementById('stream_id').value = cs.stream_id || "";
    document.getElementById('fps_limit').value = cs.fps_limit || "";
    document.getElementById('output_window_name').value = cs.OUTPUT_WINDOW_NAME || "";
    document.getElementById('window_width').value = cs.WINDOW_WIDTH || "";
    document.getElementById('window_height').value = cs.WINDOW_HEIGHT || "";
    document.getElementById('resize_scale').value = cs.resize_scale || "";

    // ---- Face recognition
    document.getElementById('process_frame_scale').value = fr.PROCESS_FRAME_SCALE || "";
    document.getElementById('recognition_tolerance').value = fr.RECOGNITION_TOLERANCE || "";
    document.getElementById('cosine_similarity_threshold').value = fr.COSINE_SIMILARITY_THRESHOLD || "";
    document.getElementById('door_open_cooldown').value = fr.DOOR_OPEN_COOLDOWN || "";
    document.getElementById('reset_door_timer').value = fr.RESET_DOOR_TIMER || "";
    document.getElementById('image_send_cooldown').value = fr.IMAGE_SEND_COOLDOWN || "";
    document.getElementById('detection_width').value = fr.detection_width || "";
    document.getElementById('detection_height').value = fr.detection_height || "";

    // ---- Directories
    document.getElementById('known_faces_dir').value = dr.KNOWN_FACES_DIR || "";
    document.getElementById('encodings_file').value = dr.ENCODINGS_FILE || "";

    // ---- MQTT
    document.getElementById('mqtt_broker_address').value = mq.MQTT_BROKER_ADDRESS || "";
    document.getElementById('mqtt_broker_port').value = mq.MQTT_BROKER_PORT || "";
    document.getElementById('mqtt_client_id').value = mq.MQTT_CLIENT_ID || "";
    document.getElementById('mqtt_username').value = mq.MQTT_USERNAME || "";
    document.getElementById('mqtt_password').value = mq.MQTT_PASSWORD || "";
    document.getElementById('mqtt_face_topic').value = mq.MQTT_FACE_TOPIC || "";

    // ---- Optimization
    document.getElementById('detection_interval_seconds').value = opt.detection_interval_seconds || "";
    document.getElementById('tracker_type').value = opt.tracker_type || "KCF";

    console.log("Configuration applied successfully!");
  } catch (err) {
    console.error("Error loading config!", err);
    alert("Failed to load configuration: " + err.message);
  }
}

// call automatically on DOM load
window.addEventListener('DOMContentLoaded', loadConfig);
