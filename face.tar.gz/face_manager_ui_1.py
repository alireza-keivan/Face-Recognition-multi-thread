
# face_manager_ui.py
from flask import Flask, render_template, request, jsonify, redirect, url_for
import subprocess
import os
import pickle
import cv2
import numpy as np
from insightface.app import FaceAnalysis
from werkzeug.utils import secure_filename
import json
import subprocess
import logging

app = Flask(__name__)

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Load configuration
CONFIG_FILE = "config.json"
with open(CONFIG_FILE, 'r') as f:
    config = json.load(f)

# Extract paths from config
KNOWN_FACES_DIR = config['directories']['KNOWN_FACES_DIR']
ENCODINGS_FILE = config['directories']['ENCODINGS_FILE']
UPLOAD_FOLDER = 'temp_uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}

# Create directories if they don't exist
os.makedirs(KNOWN_FACES_DIR, exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Initialize InsightFace
print("Initializing InsightFace model...")
face_app = FaceAnalysis(name='buffalo_l', providers=['CPUExecutionProvider'])
face_app.prepare(ctx_id=-1, det_size=(320, 320))
print("InsightFace model loaded successfully!")

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_existing_encodings():
    """Load existing face encodings from pickle file"""
    if os.path.exists(ENCODINGS_FILE):
        try:
            with open(ENCODINGS_FILE, 'rb') as f:
                data = pickle.load(f)
            return data.get('encodings', []), data.get('names', [])
        except Exception as e:
            print(f"Error loading encodings: {e}")
            return [], []
    return [], []

def save_encodings(encodings, names):
    """Save face encodings to pickle file"""
    try:
        os.makedirs(os.path.dirname(ENCODINGS_FILE), exist_ok=True)
        with open(ENCODINGS_FILE, 'wb') as f:
            pickle.dump({'encodings': encodings, 'names': names}, f)
        return True
    except Exception as e:
        print(f"Error saving encodings: {e}")
        return False

def restart_recognition_service():
    """Restart the face recognition engine via systemd"""
    try:
        result = subprocess.run(
            ['sudo', 'systemctl', 'restart', 'face-recognition.service'],
            capture_output=True,
            text=True,
            timeout=10
        )
        if result.returncode == 0:
            logger.info("Face recognition restarted successfully")
            return True, "Recognition restarted successfully"
        else:
            logger.error(f"Failed to restart service: {result.stderr}")
            return False, f"Restart failed: {result.stderr}"
    except subprocess.TimeoutExpired:
        logger.error("Restart command timed out")
        return False, "Restart command timed out"
    except Exception as e:
        logger.error(f"Error restarting service: {e}")
        return False, f"Error: {str(e)}"

def get_recognition_service_status():
    """Get status of face recognition engine"""
    try:
        result = subprocess.run(
            ['systemctl', 'is-active', 'face-recognition.service'],
            capture_output=True,
            text=True,
            timeout=5
        )
        return result.stdout.strip()  # Returns: active, inactive, failed, etc.
    except Exception as e:
        logger.error(f"Error checking service status: {e}")
        return "unknown"

def process_face_image(image_path, person_name):
    """Process uploaded image and extract face embedding"""
    try:
        # Read image
        image = cv2.imread(image_path)
        if image is None:
            return False, "Could not read image file"

        # Convert to RGB
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)

        # Detect faces
        faces = face_app.get(image_rgb)

        if len(faces) == 0:
            return False, "No face detected in the image. Please upload a clear photo with a visible face."

        if len(faces) > 1:
            return False, f"Multiple faces detected ({len(faces)} faces). Please upload an image with only one face."

        # Get face embedding
        face_embedding = faces[0].embedding

        # Load existing encodings
        encodings, names = load_existing_encodings()

        # Check if person already exists
        if person_name in names:
            # Update existing person's encoding
            idx = names.index(person_name)
            encodings[idx] = face_embedding
            print(f"Updated encoding for existing person: {person_name}")
        else:
            # Add new person
            encodings.append(face_embedding)
            names.append(person_name)
            print(f"Added new person: {person_name}")

        # Save updated encodings
        if not save_encodings(encodings, names):
            return False, "Failed to save encodings to file"

        # Save image to known faces directory
        image_filename = f"{person_name}.jpg"
        destination_path = os.path.join(KNOWN_FACES_DIR, image_filename)

        # If file exists, add number suffix
        counter = 1
        while os.path.exists(destination_path):
            image_filename = f"{person_name}_{counter}.jpg"
            destination_path = os.path.join(KNOWN_FACES_DIR, image_filename)
            counter += 1

        cv2.imwrite(destination_path, image)
        print(f"Saved image to: {destination_path}")

        # Auto-restart recognition engine after adding face
        restart_recognition_service()

        return True, f"Successfully added {person_name} to the database!"

    except Exception as e:
        return False, f"Error processing image: {str(e)}"

@app.route('/')
def index():
    """Main page"""
    encodings, names = load_existing_encodings()
    total_faces = len(names)
    service_status = get_recognition_service_status()
    return render_template('index.html', 
                         total_faces=total_faces, 
                         known_faces=names,
                         service_status=service_status)

@app.route('/upload', methods=['POST'])
def upload_file():
    """Handle file upload"""
    # Check if file and name are provided
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file uploaded'})

    if 'person_name' not in request.form or not request.form['person_name'].strip():
        return jsonify({'success': False, 'message': 'Please provide a person name'})

    file = request.files['file']
    person_name = request.form['person_name'].strip()

    # Validate filename
    if file.filename == '':
        return jsonify({'success': False, 'message': 'No file selected'})

    if not allowed_file(file.filename):
        return jsonify({'success': False, 'message': 'Invalid file type. Please upload JPG, JPEG, or PNG'})

    try:
        # Save uploaded file temporarily
        filename = secure_filename(file.filename)
        temp_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(temp_path)

        # Process the image
        success, message = process_face_image(temp_path, person_name)

        # Clean up temporary file
        if os.path.exists(temp_path):
            os.remove(temp_path)

        return jsonify({'success': success, 'message': message})

    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

@app.route('/list_faces')
def list_faces():
    """Get list of all known faces"""
    encodings, names = load_existing_encodings()
    return jsonify({'total': len(names), 'names': names})

@app.route('/delete_face/<person_name>', methods=['POST'])
def delete_face(person_name):
    """Delete a person from the database"""
    try:
        encodings, names = load_existing_encodings()

        if person_name not in names:
            return jsonify({'success': False, 'message': f'Person "{person_name}" not found'})

        # Remove from lists
        idx = names.index(person_name)
        del encodings[idx]
        del names[idx]

        # Save updated encodings
        save_encodings(encodings, names)

        # Try to delete image file(s)
        deleted_files = []
        for filename in os.listdir(KNOWN_FACES_DIR):
            if filename.startswith(person_name) and filename.lower().endswith(('.png', '.jpg', '.jpeg')):
                file_path = os.path.join(KNOWN_FACES_DIR, filename)
                os.remove(file_path)
                deleted_files.append(filename)

        # Auto-restart recognition engine after deleting face
        restart_recognition_service()

        return jsonify({
            'success': True,
            'message': f'Successfully deleted {person_name}',
            'deleted_files': deleted_files
        })

    except Exception as e:
        return jsonify({'success': False, 'message': f'Error: {str(e)}'})

@app.route('/config', methods=['GET', 'POST'])
def manage_config():
    """Get or update config.json"""
    if request.method == 'GET':
        try:
            with open(CONFIG_FILE, 'r') as f:
                config_data = json.load(f)
            return jsonify({'success': True, 'config': config_data})
        except Exception as e:
            return jsonify({'success': False, 'message': f'Error reading config: {str(e)}'})
    
    elif request.method == 'POST':
        try:
            new_config = request.json
            
            # Validate JSON structure (basic check)
            if not isinstance(new_config, dict):
                return jsonify({'success': False, 'message': 'Invalid config format'})
            
            # Backup current config
            backup_file = CONFIG_FILE + '.backup'
            with open(CONFIG_FILE, 'r') as f:
                with open(backup_file, 'w') as bf:
                    bf.write(f.read())

            # Save new config
            with open(CONFIG_FILE, 'w') as f:
                json.dump(new_config, f, indent=4)

            logger.info("Config updated successfully")

            # Restart recognition engine with new config
            success, message = restart_recognition_service()

            return jsonify({
                'success': True, 
                'message': 'Config saved and recognition engine restarted',
                'restart_status': message
            })

        except Exception as e:
            logger.error(f"Error updating config: {e}")
            return jsonify({'success': False, 'message': f'Error: {str(e)}'})

@app.route('/service/status')
def service_status():
    """Get recognition engine status"""
    status = get_recognition_service_status()
    return jsonify({'status': status})

@app.route('/service/restart', methods=['POST'])
def service_restart():
    """Manually restart recognition engine"""
    success, message = restart_recognition_service()
    return jsonify({'success': success, 'message': message})

@app.route('/get_config')
def get_config():
    """Serve configuration data to frontend"""
    try:
        with open(CONFIG_FILE, 'r') as f:
            config_data = json.load(f)
        return jsonify(config_data)
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/save_config', methods=['POST'])
def save_config():
    """Save configuration changes"""
    try:
        # Get JSON data from request
        new_config = request.get_json()
        
        if not new_config:
            return jsonify({'success': False, 'message': 'No configuration data received'})
        
        # Validate that required sections exist
        required_sections = ['camera_settings', 'face_recognition_settings', 
                           'directories', 'mqtt_settings', 'optimization_settings']
        
        for section in required_sections:
            if section not in new_config:
                return jsonify({'success': False, 'message': f'Missing required section: {section}'})
        
        # Backup existing config
        backup_file = CONFIG_FILE + '.backup'
        if os.path.exists(CONFIG_FILE):
            import shutil
            shutil.copy2(CONFIG_FILE, backup_file)
        
        # Save new config
        with open(CONFIG_FILE, 'w') as f:
            json.dump(new_config, f, indent=4)
        
        # Restart the face recognition engine service to apply changes
        try:
            import subprocess
            result = subprocess.run(
                ['sudo', 'systemctl', 'restart', 'face-recognition.service'],
                capture_output=True,
                text=True,
                timeout=10
            )
            
            if result.returncode == 0:
                restart_msg = "Configuration saved and face recognition engine restarted successfully!"
            else:
                restart_msg = f"Configuration saved, but engine restart failed: {result.stderr}"
        except Exception as restart_error:
            restart_msg = f"Configuration saved, but could not restart engine: {str(restart_error)}"
        
        return jsonify({'success': True, 'message': restart_msg})
    
    except Exception as e:
        return jsonify({'success': False, 'message': f'Error saving configuration: {str(e)}'})


if __name__ == '__main__':
    print("=" * 50)
    print("Face Recognition Manager UI")
    print("=" * 50)
    print(f"Known faces directory: {KNOWN_FACES_DIR}")
    print(f"Encodings file: {ENCODINGS_FILE}")
    print("=" * 50)
    print("Starting web server...")
    print("Access the UI at: http://localhost:5000")
    print("=" * 50)
    app.run(debug=True, host='0.0.0.0', port=5000)
