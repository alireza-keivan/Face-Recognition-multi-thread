#!/bin/bash

echo "=========================================="
echo "LOG ROTATION VERIFICATION"
echo "=========================================="
echo ""

# Check if service is running
echo "1. Checking service status..."
SERVICE_STATUS=$(systemctl is-active face-recognition.service)
echo "   Service status: $SERVICE_STATUS"

# Check service start time
echo ""
echo "2. Checking service start time..."
SERVICE_START=$(systemctl show face-recognition.service -p ActiveEnterTimestamp | cut -d= -f2)
echo "   Started: $SERVICE_START"

# Check thread.py modification time
echo ""
echo "3. Checking thread.py modification time..."
THREAD_MOD=$(stat -c %y /home/face/Face-Recognition-multi-thread/thread.py | cut -d. -f1)
echo "   Modified: $THREAD_MOD"

# Check if today's folder exists
TODAY=$(date +"%Y/%B/%d")
TODAY_PATH="/home/face/Face-Recognition-multi-thread/saved_faces/$TODAY"
echo ""
echo "4. Checking today's folder..."
echo "   Path: $TODAY_PATH"
if [ -d "$TODAY_PATH" ]; then
    echo "   Status: ✓ Exists"
    FILE_COUNT=$(ls -1 "$TODAY_PATH" 2>/dev/null | wc -l)
    echo "   Files: $FILE_COUNT"
    if [ $FILE_COUNT -gt 0 ]; then
        echo ""
        echo "   Recent files:"
        ls -lht "$TODAY_PATH" | head -5
    fi
else
    echo "   Status: ✗ Does not exist (will be created automatically)"
fi

# Check for any new files in old location
echo ""
echo "5. Checking for files in old flat structure (should be empty after restart)..."
NEW_FILES=$(find /home/face/Face-Recognition-multi-thread/saved_faces -maxdepth 1 -type f -name "*.jpg" -newer /home/face/Face-Recognition-multi-thread/thread.py 2>/dev/null | wc -l)
echo "   New files in root: $NEW_FILES"
if [ $NEW_FILES -gt 0 ]; then
    echo "   ⚠️  WARNING: Service may not have been restarted yet!"
fi

echo ""
echo "=========================================="
echo "RECOMMENDATION"
echo "=========================================="
if [ "$SERVICE_STATUS" = "active" ]; then
    THREAD_EPOCH=$(stat -c %Y /home/face/Face-Recognition-multi-thread/thread.py)
    SERVICE_EPOCH=$(date -d "$SERVICE_START" +%s 2>/dev/null || echo "0")
    
    if [ $THREAD_EPOCH -gt $SERVICE_EPOCH ]; then
        echo "⚠️  Service is running OLD code!"
        echo ""
        echo "Please restart the service:"
        echo "  sudo systemctl restart face-recognition.service"
    else
        echo "✓ Service is running with latest code"
    fi
else
    echo "⚠️  Service is not running. Please start it:"
    echo "  sudo systemctl start face-recognition.service"
fi
echo ""
