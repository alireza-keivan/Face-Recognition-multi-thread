# Database Connection Fix - Summary

## Date: December 22, 2025

## Problem
Face recognition system was detecting faces and saving images to `saved_faces/` directory, but **NO NEW RECORDS** were being inserted into the PostgreSQL database.

### Symptoms:
- ✅ Face detection working (images saved)
- ✅ Web app working (showing old records)
- ❌ New recognitions NOT being logged to database
- ❌ Only 8 old records visible (from initial testing)

### Error in Logs:
```
Error logging recognition: password authentication failed for user "face_user"
```

## Root Cause
The `thread.py` script imports `DatabaseManager` from `webapp/database.py`, which has an import path issue:

1. **thread.py** adds `/webapp` to `sys.path`:
   ```python
   WEBAPP_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'webapp')
   sys.path.insert(0, WEBAPP_DIR)
   from webapp.database import DatabaseManager
   ```

2. **database.py** was trying to import config as:
   ```python
   from webapp.config import DB_CONFIG  # ❌ FAILS when called from thread.py
   ```

3. **Fallback credentials** were incorrect:
   ```python
   db_url = "postgresql://face_user:123456@localhost:5432/face_recognition_db"
   #                      ^^^^^^^^^ WRONG! Should be "face"
   ```

4. **Actual database** uses username `face` (not `face_user`):
   ```python
   # webapp/config.py
   DB_CONFIG = {
       'user': 'face',  # ✓ Correct
       'password': '123456',
       ...
   }
   ```

## Solution

### Fixed Import Path in `webapp/database.py` (Lines 108-121):

**Before:**
```python
try:
    from webapp.config import DB_CONFIG
    db_url = f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
    logger.info(f"Using database config from webapp.config")
except ImportError:
    # Fallback with WRONG username
    db_url = "postgresql://face_user:123456@localhost:5432/face_recognition_db"
    logger.info("Using fallback database config")
```

**After:**
```python
try:
    # Try relative import first (when called from within webapp)
    try:
        from .config import DB_CONFIG
    except ImportError:
        # Try direct import (when webapp is in sys.path from thread.py)
        from config import DB_CONFIG
    
    db_url = f"postgresql://{DB_CONFIG['user']}:{DB_CONFIG['password']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}"
    logger.info(f"Using database config: {DB_CONFIG['user']}@{DB_CONFIG['host']}:{DB_CONFIG['port']}/{DB_CONFIG['database']}")
except (ImportError, KeyError) as e:
    # Fallback with CORRECT username
    db_url = "postgresql://face:123456@localhost:5432/face_recognition_db"
    logger.warning(f"Failed to import config ({e}), using fallback database config")
```

### Changes Made:
1. ✅ Fixed import to work from both contexts (relative and direct)
2. ✅ Corrected fallback username from `face_user` to `face`
3. ✅ Added better logging to show which config is being used
4. ✅ Added exception handling for KeyError

## Verification

### Before Fix:
```bash
$ psql -U face -d face_recognition_db -c "SELECT COUNT(*) FROM recognition_logs;"
 count 
-------
     8
(Only old test records)
```

### After Fix:
```bash
$ python -c "from webapp.database import DatabaseManager; ..."
=== LATEST 10 RECORDS ===
ID: 15, Person: علیرضا کیوان, Time: 2025-12-22T13:33:07, Confidence: 0.518
ID: 14, Person: علیرضا کیوان, Time: 2025-12-22T13:33:01, Confidence: 0.642
ID: 13, Person: علیرضا کیوان, Time: 2025-12-22T13:32:57, Confidence: 0.628
...
```

**NEW RECORDS BEING CREATED! ✅**

### Service Status:
```bash
$ sudo systemctl status face-recognition.service
● face-recognition.service - Face Recognition Application Service
     Active: active (running) since Mon 2025-12-22 13:31:57 +0330
```

### Log Output (After Fix):
```
2025-12-22 13:32:57,620 - INFO - DB Log: علیرضا کیوان, similarity: 0.628, verified: True
2025-12-22 13:33:01,966 - INFO - ✓ Logged recognition: علیرضا کیوان at 2025-12-22 13:33:01.950927 (similarity: 0.6422255635261536)
2025-12-22 13:33:07,367 - INFO - DB Log: علیرضا کیوان, similarity: 0.518, verified: True
```

## Files Modified
- `/home/face/Face-Recognition-multi-thread/webapp/database.py` (Lines 108-121)

## Services Restarted
```bash
sudo systemctl restart face-recognition.service
sudo systemctl restart face-webapp.service
```

## Testing
1. ✅ Face detection working
2. ✅ Images saving to `saved_faces/`
3. ✅ Database logging working (NEW records being created)
4. ✅ Web app showing new logs
5. ✅ MQTT publishing working

## Summary
The issue was a **Python import path conflict** combined with **incorrect fallback credentials**. The fix ensures that `database.py` can properly import the database configuration regardless of whether it's called from:
- The Flask web app (inside `webapp/`)
- The face recognition script (`thread.py` from project root)

The system is now fully operational and logging all new face recognitions to the database! 🎉
