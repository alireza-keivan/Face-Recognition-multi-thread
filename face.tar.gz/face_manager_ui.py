#!/usr/bin/env python3
"""
face_manager_ui.py - Web panel for managing face-recognition service.
Pre-filled editable fields for all config options, face management, and auto service restart.
"""
from database import DatabaseManager
import os
import json
import shutil
import subprocess
from pathlib import Path
from flask import (
    Flask,
    render_template,
    request,
    jsonify,
    send_from_directory
)
from werkzeug.utils import secure_filename

# =============================================================================
# Database Integration
# =============================================================================
try:
    from database import DatabaseManager, RecognitionLog
    db_manager = DatabaseManager()
    print("✅ Database connection established")
except Exception as e:
    print(f"⚠️ Database not available: {e}")
    db_manager = None

# =============================================================================
# CONFIGURATION - Adjust these paths to match your server
# =============================================================================
CONFIG_PATH = "/home/face/Face-Recognition-multi-thread/config.json"
FACES_DIR = "/home/face/Face-Recognition-multi-thread/captured_known_faces"
SERVICE_NAME = "face-recognition.service"
EXIT_SCRIPT_PATH = "/home/face/Face-Recognition-multi-thread/exit.bash"

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif', 'bmp', 'webp'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max upload

# =============================================================================
# Flask Initialization
# =============================================================================
app = Flask(__name__)
app.secret_key = os.urandom(24)
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH
try:
    db_manager = DatabaseManager()
except Exception as e:
    print(f"Warning: Database not available: {e}")
    db_manager = None

# =============================================================================
# Helper Functions
# =============================================================================

def allowed_file(filename: str) -> bool:
    """Check if file extension is allowed."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def restart_service() -> dict:
    """Restart the face-recognition systemd service."""
    try:
        result = subprocess.run(
            ['sudo', 'systemctl', 'restart', SERVICE_NAME],
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode == 0:
            return {'success': True, 'message': f'Service {SERVICE_NAME} restarted successfully'}
        else:
            return {'success': False, 'message': f'Restart failed: {result.stderr}'}
    except subprocess.TimeoutExpired:
        return {'success': False, 'message': 'Service restart timed out'}
    except Exception as e:
        return {'success': False, 'message': f'Error: {str(e)}'}


def stop_service() -> dict:
    """Stop the face-recognition service."""
    try:
        result = subprocess.run(
            ['sudo', 'systemctl', 'stop', SERVICE_NAME],
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode == 0:
            return {'success': True, 'message': f'Service {SERVICE_NAME} stopped'}
        else:
            return {'success': False, 'message': f'Stop failed: {result.stderr}'}
    except Exception as e:
        return {'success': False, 'message': f'Error: {str(e)}'}


def start_service() -> dict:
    """Start the face-recognition service."""
    try:
        result = subprocess.run(
            ['sudo', 'systemctl', 'start', SERVICE_NAME],
            capture_output=True,
            text=True,
            timeout=30
        )
        if result.returncode == 0:
            return {'success': True, 'message': f'Service {SERVICE_NAME} started'}
        else:
            return {'success': False, 'message': f'Start failed: {result.stderr}'}
    except Exception as e:
        return {'success': False, 'message': f'Error: {str(e)}'}


def get_service_status() -> dict:
    """Get current status of the face-recognition service."""
    try:
        # Get active state
        result = subprocess.run(
            ['sudo', 'systemctl', 'is-active', SERVICE_NAME],
            capture_output=True,
            text=True,
            timeout=10
        )
        status = result.stdout.strip()
        
        # Get more detailed status
        detail_result = subprocess.run(
            ['sudo', 'systemctl', 'status', SERVICE_NAME, '--no-pager', '-l'],
            capture_output=True,
            text=True,
            timeout=10
        )
        
        return {
            'status': status,
            'running': status == 'active',
            'details': detail_result.stdout[:500] if detail_result.stdout else ''
        }
    except Exception as e:
        return {'status': 'unknown', 'running': False, 'error': str(e)}


def load_config() -> dict:
    """Load configuration from JSON file."""
    try:
        with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return {'_error': 'Config file not found'}
    except json.JSONDecodeError as e:
        return {'_error': f'Invalid JSON: {str(e)}'}


def save_config(config: dict) -> bool:
    """Save configuration to JSON file with backup."""
    try:
        # Create backup
        if os.path.exists(CONFIG_PATH):
            backup_path = f"{CONFIG_PATH}.bak"
            shutil.copy2(CONFIG_PATH, backup_path)
        
        with open(CONFIG_PATH, 'w', encoding='utf-8') as f:
            json.dump(config, f, indent=4, ensure_ascii=False)
        return True
    except Exception as e:
        app.logger.error(f"Failed to save config: {e}")
        return False


def get_faces_list() -> list:
    """Get hierarchical list of all faces in FACES_DIR."""
    faces = []
    faces_path = Path(FACES_DIR)
    
    if not faces_path.exists():
        faces_path.mkdir(parents=True, exist_ok=True)
        return faces
    
    for item in sorted(faces_path.iterdir()):
        if item.is_dir():
            # Person folder with images inside
            images = []
            for img in sorted(item.iterdir()):
                if img.is_file() and allowed_file(img.name):
                    images.append({
                        'name': img.name,
                        'path': str(img.relative_to(faces_path)),
                        'size': img.stat().st_size,
                        'size_kb': round(img.stat().st_size / 1024, 1)
                    })
            faces.append({
                'type': 'folder',
                'name': item.name,
                'path': item.name,
                'images': images,
                'image_count': len(images)
            })
        elif item.is_file() and allowed_file(item.name):
            # Standalone image
            faces.append({
                'type': 'image',
                'name': item.name,
                'path': item.name,
                'size': item.stat().st_size,
                'size_kb': round(item.stat().st_size / 1024, 1)
            })
    
    return faces


def convert_form_to_config(form_data) -> dict:
    """Convert flat form data to nested config structure."""
    config = {
        "camera_settings": {},
        "face_recognition_settings": {},
        "directories": {},
        "mqtt_settings": {},
        "optimization_settings": {},
        "operation_region": {},
        "openvino_settings": {}
    }
    
    # Type mappings for proper conversion
    int_fields = {
        'WINDOW_WIDTH', 'WINDOW_HEIGHT', 'DOOR_OPEN_COOLDOWN', 'RESET_DOOR_TIMER',
        'IMAGE_SEND_COOLDOWN', 'detection_width', 'detection_height',
        'MQTT_BROKER_PORT', 'x1', 'x2', 'y1', 'y2', 'door_num'
    }
    float_fields = {
        'fps_limit', 'resize_scale', 'PROCESS_FRAME_SCALE', 'RECOGNITION_TOLERANCE',
        'COSINE_SIMILARITY_THRESHOLD', 'detection_interval_seconds'
    }
    
    for key, value in form_data.items():
        if '.' in key:
            section, field = key.split('.', 1)
            if section in config:
                # Convert to proper type
                if field in int_fields:
                    try:
                        config[section][field] = int(value)
                    except ValueError:
                        config[section][field] = value
                elif field in float_fields:
                    try:
                        config[section][field] = float(value)
                    except ValueError:
                        config[section][field] = value
                else:
                    config[section][field] = value
    
    return config


# =============================================================================
# Routes - Web Interface
# =============================================================================

@app.route('/')
def index():
    """Main dashboard page."""
    config = load_config()
    faces = get_faces_list()
    service_status = get_service_status()
    
    return render_template(
        'index.html',
        config=config,
        faces=faces,
        service_status=service_status,
        config_path=CONFIG_PATH,
        faces_dir=FACES_DIR
    )
@app.route('/faces')
def faces_page():
    """Face management page."""
    return render_template('faces.html')

@app.route('/config')
def config_page():
    """Configuration page."""
    config = load_config()
    return render_template('config.html', config=config)

@app.route('/faces/<path:filename>')
def serve_face_image(filename):
    """Serve face images for preview."""
    return send_from_directory(FACES_DIR, filename)


# =============================================================================
# API Routes - Configuration
# =============================================================================

@app.route('/api/config', methods=['GET'])
def api_get_config():
    """Return current config as JSON."""
    config = load_config()
    return jsonify({'success': True, 'config': config})


@app.route('/api/config', methods=['POST'])
def api_save_config():
    """Save config from form fields and restart service."""
    try:
        if request.is_json:
            new_config = request.get_json()
        else:
            # Convert form data to nested config
            new_config = convert_form_to_config(request.form.to_dict())
        
        if save_config(new_config):
            restart_result = restart_service()
            return jsonify({
                'success': True,
                'message': 'Configuration saved successfully',
                'restart': restart_result
            })
        else:
            return jsonify({'success': False, 'message': 'Failed to save config'}), 500
            
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/config/raw', methods=['POST'])
def api_save_config_raw():
    """Save raw JSON config (from textarea editor)."""
    try:
        data = request.get_json()
        config_text = data.get('config', '')
        new_config = json.loads(config_text)
        
        if save_config(new_config):
            restart_result = restart_service()
            return jsonify({
                'success': True,
                'message': 'Configuration saved successfully',
                'restart': restart_result
            })
        else:
            return jsonify({'success': False, 'message': 'Failed to save config'}), 500
            
    except json.JSONDecodeError as e:
        return jsonify({'success': False, 'message': f'Invalid JSON: {str(e)}'}), 400
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


# =============================================================================
# API Routes - Faces Management
# =============================================================================

@app.route('/api/faces', methods=['GET'])
def api_get_faces():
    """Return list of all faces."""
    faces = get_faces_list()
    return jsonify({'success': True, 'faces': faces})


@app.route('/api/faces/upload', methods=['POST'])
def api_upload_face():
    """Upload new face image(s)."""
    if 'file' not in request.files:
        return jsonify({'success': False, 'message': 'No file provided'}), 400

    files = request.files.getlist('file')
    person_name = request.form.get('person_name', '').strip()

    if not files or files[0].filename == '':
        return jsonify({'success': False, 'message': 'No file selected'}), 400

    uploaded = []
    errors = []

    for file in files:
        if not allowed_file(file.filename):
            errors.append(f'{file.filename}: invalid type')
            continue

        try:
            # CHANGED: Preserve original filename instead of using secure_filename
            # Only remove path separators and null bytes for security
            filename = file.filename
            filename = filename.replace('/', '').replace('\\', '').replace('\x00', '')
            filename = filename.strip()
            
            if not filename:
                errors.append(f'{file.filename}: invalid filename')
                continue

            # Determine target directory
            if person_name:
                # Also preserve Persian/Unicode in folder names
                safe_folder = person_name.replace('/', '').replace('\\', '').replace('\x00', '').strip()
                target_dir = Path(FACES_DIR)
            else:
                target_dir = Path(FACES_DIR)

            target_dir.mkdir(parents=True, exist_ok=True)

            # Handle filename conflicts
            target_path = target_dir / filename
            if target_path.exists():
                base, ext = os.path.splitext(filename)
                counter = 1
                while target_path.exists():
                    filename = f"{base}_{counter}{ext}"
                    target_path = target_dir / filename
                    counter += 1

            file.save(str(target_path))
            uploaded.append(filename)

        except Exception as e:
            errors.append(f'{file.filename}: {str(e)}')

    if uploaded:
        restart_result = restart_service()
        return jsonify({
            'success': True,
            'message': f'Uploaded {len(uploaded)} file(s)',
            'uploaded': uploaded,
            'errors': errors,
            'restart': restart_result
        })
    else:
        return jsonify({
            'success': False,
            'message': 'No files uploaded',
            'errors': errors
        }), 400

@app.route('/api/faces/delete', methods=['POST'])
def api_delete_face():
    """Delete a face image or folder."""
    data = request.get_json() if request.is_json else request.form
    path = data.get('path', '').strip()
    
    if not path:
        return jsonify({'success': False, 'message': 'No path provided'}), 400
    
    # Security check
    if '..' in path or path.startswith('/'):
        return jsonify({'success': False, 'message': 'Invalid path'}), 400
    
    try:
        target_path = Path(FACES_DIR) / path
        
        # Ensure path is within FACES_DIR
        if not str(target_path.resolve()).startswith(str(Path(FACES_DIR).resolve())):
            return jsonify({'success': False, 'message': 'Invalid path'}), 400
        
        if not target_path.exists():
            return jsonify({'success': False, 'message': 'Not found'}), 404
        
        if target_path.is_dir():
            shutil.rmtree(str(target_path))
            msg = f'Deleted folder: {path}'
        else:
            target_path.unlink()
            msg = f'Deleted: {path}'
        
        try:
            pkl_path = Path("/home/face/Face-Recognition-multi-thread/known_faces_data.pkl")
            if pkl_path.exists():
                pkl_path.unlink()
        except Exception as pkl_err:
            app.logger.warning(f"Could not delete PKL file: {pkl_err}")

            restart_result = restart_service()
        
        return jsonify({
            'success': True,
            'message': msg,
            'restart': restart_result
        })
        
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/faces/folder', methods=['POST'])
def api_create_folder():
    """Create a new person folder."""
    data = request.get_json() if request.is_json else request.form
    folder_name
    folder_name = data.get('folder_name', '').strip()

    if not folder_name:
        return jsonify({'success': False, 'message': 'Folder name is required'}), 400

    safe_name = secure_filename(folder_name)
    target_dir = Path(FACES_DIR) / safe_name

    if target_dir.exists():
        return jsonify({'success': False, 'message': 'Folder already exists'}), 400

    try:
        target_dir.mkdir(parents=True, exist_ok=False)
        restart_result = restart_service()
        return jsonify({
            'success': True,
            'message': f'Folder "{safe_name}" created',
            'restart': restart_result
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500
# =============================================================================
# API Routes - Service Management
# =============================================================================

@app.route('/api/service/status', methods=['GET'])
def api_service_status():
    """Return current service status."""
    status = get_service_status()
    return jsonify({'success': True, 'status': status})


@app.route('/api/service/restart', methods=['POST'])
def api_service_restart():
    """Restart face-recognition service."""
    result = restart_service()
    return jsonify(result)


@app.route('/api/service/stop', methods=['POST'])
def api_service_stop():
    """Stop the service."""
    result = stop_service()
    return jsonify(result)


@app.route('/api/service/start', methods=['POST'])
def api_service_start():
    """Start the service."""
    result = start_service()
    return jsonify(result)
# =============================================================================
# API Routes - Exit Script Management
# =============================================================================

@app.route('/api/exit', methods=['GET'])
def api_read_exit_script():
    """Return the contents of exit.bash."""
    try:
        if not os.path.exists(EXIT_SCRIPT_PATH):
            return jsonify({'success': False, 'message': 'exit.bash not found'}), 404
        with open(EXIT_SCRIPT_PATH, 'r', encoding='utf-8') as f:
            content = f.read()
        return jsonify({'success': True, 'content': content})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/exit', methods=['POST'])
def api_save_exit_script():
    """Update and save exit.bash."""
    try:
        data = request.get_json() if request.is_json else request.form
        new_content = data.get('content', '')
        if not new_content.strip():
            return jsonify({'success': False, 'message': 'No content provided'}), 400

        # Backup old file
        if os.path.exists(EXIT_SCRIPT_PATH):
            shutil.copy2(EXIT_SCRIPT_PATH, f"{EXIT_SCRIPT_PATH}.bak")

        with open(EXIT_SCRIPT_PATH, 'w', encoding='utf-8') as f:
            f.write(new_content)
        
        # Make sure it's executable
        os.chmod(EXIT_SCRIPT_PATH, 0o755)

        restart_result = restart_service()
        return jsonify({
            'success': True,
            'message': 'exit.bash updated successfully',
            'restart': restart_result
        })
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/db/logs', methods=['GET'])
def api_db_logs():
    """Get recognition logs with filtering."""
    if not db_manager:
        return jsonify({'success': False, 'message': 'Database not configured'}), 503
    
    try:
        limit = request.args.get('limit', 100, type=int)
        offset = request.args.get('offset', 0, type=int)
        person_name = request.args.get('person', None)
        verified_only = request.args.get('verified', None)
        
        if verified_only is not None:
            verified_only = verified_only.lower() == 'true'
        
        # Use your actual method: get_recognition_logs
        logs = db_manager.get_recognition_logs(
            limit=limit,
            offset=offset,
            person_name=person_name,
            verified_only=verified_only
        )
        
        # Convert ORM objects to dictionaries using YOUR column names
        logs_data = []
        for log in logs:
            if isinstance(log, dict):
                logs_data.append(log)
            else:
                log_dict = {
                    'id': log.id,
                    'person_name': log.recognized_person,  # YOUR column name
                    'is_verified': log.identity_verified,  # YOUR column name
                    'confidence': round(float(log.cosine_similarity), 4) if log.cosine_similarity else None,
                    'timestamp': log.timestamp.isoformat() if log.timestamp else None,
                    'created_at': log.created_at.isoformat() if log.created_at else None,
                    'image_path': log.image_path,
                    'image_filename': log.image_filename,
                    'door_number': log.door_num,  # YOUR column name
                    'face_bbox': {
                        'x1': log.face_x1,
                        'y1': log.face_y1,
                        'x2': log.face_x2,
                        'y2': log.face_y2
                    },
                    'operation_region': {
                        'x1': log.region_x1,
                        'y1': log.region_y1,
                        'x2': log.region_x2,
                        'y2': log.region_y2
                    }
                }
                logs_data.append(log_dict)
        
        return jsonify({'success': True, 'logs': logs_data, 'count': len(logs_data)})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/db/logs/recent', methods=['GET'])
def api_db_logs_recent():
    """Get recent recognition events (last N minutes)."""
    if not db_manager:
        return jsonify({'success': False, 'message': 'Database not configured'}), 503
    
    try:
        minutes = request.args.get('minutes', 60, type=int)
        
        from datetime import datetime, timedelta, timezone
        from sqlalchemy import desc
        
        since = datetime.now(timezone.utc) - timedelta(minutes=minutes)
        
        with db_manager.get_session() as session:
            logs = session.query(RecognitionLog).filter(
                RecognitionLog.timestamp >= since
            ).order_by(
                desc(RecognitionLog.timestamp)
            ).limit(50).all()
            
            # Convert to dicts while session is open
            results = []
            for log in logs:
                results.append({
                    'id': log.id,
                    'person_name': log.recognized_person,
                    'is_verified': log.identity_verified,
                    'confidence': round(float(log.cosine_similarity), 4) if log.cosine_similarity else None,
                    'timestamp': log.timestamp.isoformat() if log.timestamp else None,
                    'door_number': log.door_num,
                    'image_filename': log.image_filename
                })
        
        return jsonify({'success': True, 'logs': results})
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/db/persons', methods=['GET'])
def api_db_persons():
    """Return unique recognized person names."""
    if not db_manager:
        return jsonify({'success': False, 'message': 'Database not configured'}), 503
    
    try:
        from sqlalchemy import func, desc
        
        with db_manager.get_session() as session:
            # Get unique persons with count and last seen
            query = session.query(
                RecognitionLog.recognized_person,
                func.count(RecognitionLog.id).label('count'),
                func.max(RecognitionLog.timestamp).label('last_seen')
            ).filter(
                RecognitionLog.recognized_person.isnot(None),
                RecognitionLog.recognized_person != 'Unknown'
            ).group_by(
                RecognitionLog.recognized_person
            ).order_by(
                desc('count')
            ).all()
            
            persons = []
            for row in query:
                persons.append({
                    'name': row[0],
                    'recognition_count': row[1],
                    'last_seen': row[2].isoformat() if row[2] else None
                })
        
        return jsonify({'success': True, 'persons': persons})
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/db/config-snapshots', methods=['GET'])
def api_db_list_snapshots():
    """List stored config snapshots."""
    if not db_manager:
        return jsonify({'success': False, 'message': 'Database not configured'}), 503
    
    try:
        # Use your actual method: get_config_snapshots
        snapshots = db_manager.get_config_snapshots()
        
        # Convert to dicts if needed
        snapshots_data = []
        for snap in snapshots:
            if isinstance(snap, dict):
                snapshots_data.append(snap)
            else:
                snapshots_data.append({
                    'id': snap.id,
                    'created_at': snap.created_at.isoformat() if hasattr(snap, 'created_at') and snap.created_at else None,
                    'description': getattr(snap, 'description', None),
                    'config_data': getattr(snap, 'config_data', None) or getattr(snap, 'config_json', None)
                })
        
        return jsonify({'success': True, 'snapshots': snapshots_data})
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/db/config-snapshots', methods=['POST'])
def api_db_save_snapshot():
    """Save the current config.json to the database."""
    if not db_manager:
        return jsonify({'success': False, 'message': 'Database not configured'}), 503
    
    try:
        data = request.get_json() or {}
        description = data.get('description', 'Manual snapshot from web panel')
        
        config = load_config()
        
        # Use your actual method: save_config_snapshot
        snapshot_id = db_manager.save_config_snapshot(config, description=description)
        
        return jsonify({
            'success': True, 
            'message': 'Config snapshot saved',
            'snapshot_id': snapshot_id
        })
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500


@app.route('/api/db/config-snapshots/<int:snapshot_id>', methods=['GET'])
def api_db_get_snapshot(snapshot_id):
    """Get a specific config snapshot by ID."""
    if not db_manager:
        return jsonify({'success': False, 'message': 'Database not configured'}), 503
    
    try:
        # Use your actual method: get_config_snapshot_by_id
        snapshot = db_manager.get_config_snapshot_by_id(snapshot_id)
        
        if not snapshot:
            return jsonify({'success': False, 'message': 'Snapshot not found'}), 404
        
        if isinstance(snapshot, dict):
            return jsonify({'success': True, 'snapshot': snapshot})
        else:
            return jsonify({'success': True, 'snapshot': {
                'id': snapshot.id,
                'created_at': snapshot.created_at.isoformat() if hasattr(snapshot, 'created_at') and snapshot.created_at else None,
                'description': getattr(snapshot, 'description', None),
                'config_data': getattr(snapshot, 'config_data', None) or getattr(snapshot, 'config_json', None)
            }})
    
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)}), 500

@app.route('/api/db/health', methods=['GET'])
def api_db_health():
    """Check database health."""
    if not db_manager:
        return jsonify({
            'success': True,
            'data': {
                'status': 'unavailable',
                'connected': False,
                'message': 'Database not configured'
            }
        })
    
    try:
        health = db_manager.health_check()
        return jsonify({'success': True, 'data': health})
    except Exception as e:
        return jsonify({
            'success': True,
            'data': {
                'status': 'error',
                'connected': False,
                'message': str(e)
            }
        })


@app.route('/api/db/stats', methods=['GET'])
def api_db_stats():
    """Get recognition statistics."""
    if not db_manager:
        return jsonify({'success': False, 'message': 'Database not configured'}), 503

    try:
        # Use your actual method: get_recognition_stats
        stats = db_manager.get_recognition_stats()

        # Ensure consistent format for frontend
        if isinstance(stats, dict):
            return jsonify({'success': True, 'stats': stats})
        else:
            return jsonify({'success': True, 'stats': {
                'total_logs': 0,
                'verified_count': 0,
                'verification_rate': 0,
                'avg_confidence': 0
            }})

    except Exception as e:
        import traceback
        traceback.print_exc()
        return jsonify({'success': False, 'message': str(e)}), 500





# =============================================================================



# MAIN ENTRYPOINT
# =============================================================================
if __name__ == '__main__':
    print("Starting Face Manager UI at http://127.0.0.1:5000")
    app.run(host='0.0.0.0', port=5000, debug=True)
