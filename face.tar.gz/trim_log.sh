#!/bin/bash

# Path to your log file
LOG_FILE="/home/face/Face-Recognition-multi-thread/face_recognition.log"

# Path to a temporary file
TEMP_FILE="/home/face/Face-Recognition-multi-thread/my-app.log.tmp"

# Check if the log file exists
if [ -f "$LOG_FILE" ]; then
    # Use tail to get the last 1000 lines and redirect to a temp file
    tail -n 1000 "$LOG_FILE" > "$TEMP_FILE"

    # Overwrite the original log file with the content of the temp file
    mv "$TEMP_FILE" "$LOG_FILE"
fi
