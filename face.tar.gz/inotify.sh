#!/bin/bash

# Configuration
SERVICE_NAME="face-recognition"
CONFIG_FILE="./config.json"
KNOWN_FACES_DIR="./captured_known_faces"
PYTHON_SCRIPT="./recognizer.py"
LOG_FILE="/var/log/face_recognition_watcher.log"
RESTART_DELAY=2  # seconds to wait before restarting

# Function to log messages
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

# Function to restart the service
restart_service() {
    log_message "Change detected! Restarting face recognition service..."
    
    # Kill existing process
    pkill -f "recognizer.py" || log_message "No existing process found"
    
    # Wait a bit for clean shutdown
    sleep $RESTART_DELAY
    
    # Start the service in background
    nohup python3 "$PYTHON_SCRIPT" > /dev/null 2>&1 &
    
    log_message "Service restarted successfully (PID: $!)"
}

# Check if inotifywait is installed
if ! command -v inotifywait &> /dev/null; then
    log_message "ERROR: inotifywait not found. Installing inotify-tools..."
    sudo apt-get update && sudo apt-get install -y inotify-tools
fi

log_message "Starting file watcher for Face Recognition System"
log_message "Monitoring: $CONFIG_FILE"
log_message "Monitoring: $KNOWN_FACES_DIR"

# Monitor for changes
inotifywait -m -e modify,create,delete,move \
    --format '%w%f %e' \
    "$CONFIG_FILE" "$KNOWN_FACES_DIR" | while read -r file event
do
    log_message "Event detected: $event on $file"
    restart_service
    
    # Cooldown period to avoid multiple rapid restarts
    sleep 5
done
