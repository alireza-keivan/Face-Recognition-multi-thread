# face_manager_ui.py
# Complete Flask management UI for Face Recognition system
from flask import Flask, render_template, request, jsonify, redirect, url_for
import os
import pickle
import cv2
import numpy as np
from insightface.app import FaceAnalysis
from werkzeug.utils import secure_filename
import json
import subprocess

# ------------------------------------------------------------
# Initial Setup
# ------------------------------------------------------------
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(SCRIPT_DIR, "config.json")
UPLOAD_FOLDER = os.path.join(SCRIPT_DIR, "temp_uploads")

# ------------------------------------------------------------
# Load configuration from absolute path
# ------------------------------------------------------------
if not os.path.exists(CONFIG_FILE):
    raise FileNotFoundError(f"Config file not found: {CONFIG_FILE}")

with open(CONFIG_FILE, "r") as f:
    config = json.load(f)

KNOWN_FACES_DIR = config["directories"]["KNOWN_FACES_DIR"]
ENCODINGS_FILE = config["directories"]["ENCODINGS_FILE"]
ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg"}

# Ensure all required directories exist
os.makedirs(KNOWN_FACES_DIR, exist_ok=True)
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.makedirs(os.path.dirname(ENCODINGS_FILE), exist_ok=True)

# Create Flask app
app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 16 * 1024 * 1024  # 16 MB max

# ------------------------------------------------------------
# Initialize InsightFace model
# ------------------------------------------------------------
print("Initializing InsightFace model...")
face_app = FaceAnalysis(name="buffalo_l", providers=["CPUExecutionProvider"])
face_app.prepare(ctx_id=-1, det_size=(320, 320))
print("InsightFace model loaded successfully!")

# ------------------------------------------------------------
# Utility functions
# ------------------------------------------------------------
def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def load_existing_encodings():
    """Load existing face encodings from pickle file"""
    if os.path.exists(ENCODINGS_FILE):
        try:
            with open(ENCODINGS_FILE, "rb") as f:
                data = pickle.load(f)
            return data.get("encodings", []), data.get("names", [])
        except Exception as e:
            print(f"Error loading encodings: {e}")
            return [], []
    return [], []


def save_encodings(encodings, names):
    """Save face encodings to pickle file"""
    try:
        with open(ENCODINGS_FILE, "wb") as f:
            pickle.dump({"encodings": encodings, "names": names}, f)
        return True
    except Exception as e:
        print(f"Error saving encodings: {e}")
        return False


def process_face_image(image_path, person_name):
    """Extract embedding and update known faces"""
    try:
        image = cv2.imread(image_path)
        if image is None:
            return False, "Could not read image file"

        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        faces = face_app.get(image_rgb)

        if len(faces) == 0:
            return False, "No face detected. Please upload a clear image."
        if len(faces) > 1:
            return False, "Multiple faces detected. Upload an image with one face."

        face_embedding = faces[0].embedding
        encodings, names = load_existing_encodings()

        if person_name in names:
            idx = names.index(person_name)
            encodings[idx] = face_embedding
            print(f"Updated encoding for {person_name}")
        else:
            encodings.append(face_embedding)
            names.append(person_name)
            print(f"Added new person: {person_name}")

        if not save_encodings(encodings, names):
            return False, "Failed to save encodings file"

        # Save image to known_faces
        image_filename = f"{person_name}.jpg"
        destination_path = os.path.join(KNOWN_FACES_DIR, image_filename)
        counter = 1
        while os.path.exists(destination_path):
            image_filename = f"{person_name}_{counter}.jpg"
            destination_path = os.path.join(KNOWN_FACES_DIR, image_filename)
            counter += 1
        cv2.imwrite(destination_path, image)
        print(f"Image saved at {destination_path}")

        return True, f"Successfully added {person_name}!"
    except Exception as e:
        return False, f"Error processing image: {str(e)}"


# ------------------------------------------------------------
# Routes
# ------------------------------------------------------------
@app.route("/")
def index():
    encodings, names = load_existing_encodings()
    total_faces = len(names)
    return render_template("index.html", total_faces=total_faces, known_faces=names)


@app.route("/upload", methods=["POST"])
def upload_file():
    if "file" not in request.files:
        return jsonify({"success": False, "message": "No file uploaded"})
    if "person_name" not in request.form or not request.form["person_name"].strip():
        return jsonify({"success": False, "message": "Person name required"})

    file = request.files["file"]
    person_name = request.form["person_name"].strip()

    if file.filename == "":
        return jsonify({"success": False, "message": "Empty filename"})
    if not allowed_file(file.filename):
        return jsonify({"success": False, "message": "Invalid file type"})

    try:
        filename = secure_filename(file.filename)
        temp_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
        file.save(temp_path)
        success, message = process_face_image(temp_path, person_name)

        if os.path.exists(temp_path):
            os.remove(temp_path)
        if success:
            subprocess.run(["sudo", "systemctl", "restart", "face-recognition.service"])
        return jsonify({"success": success, "message": message})
    except Exception as e:
        return jsonify({"success": False, "message": f"Upload error: {str(e)}"})


@app.route("/list_faces")
def list_faces():
    encodings, names = load_existing_encodings()
    return jsonify({"total": len(names), "names": names})


@app.route("/delete_face/<person_name>", methods=["POST"])
def delete_face(person_name):
    try:
        encodings, names = load_existing_encodings()
        if person_name not in names:
            return jsonify({"success": False, "message": f"{person_name} not found"})

        idx = names.index(person_name)
        del encodings[idx]
        del names[idx]
        save_encodings(encodings, names)

        deleted_files = []
        for fn in os.listdir(KNOWN_FACES_DIR):
            if fn.startswith(person_name) and fn.lower().endswith((".jpg", ".jpeg", ".png")):
                fp = os.path.join(KNOWN_FACES_DIR, fn)
                os.remove(fp)
                deleted_files.append(fn)

        subprocess.run(["sudo", "systemctl", "restart", "face-recognition.service"])
        return jsonify({"success": True, "deleted_files": deleted_files})
    except Exception as e:
        return jsonify({"success": False, "message": f"Error: {str(e)}"})


# ------------------------------------------------------------
# Config fetch + save (for config_loader.js)
# ------------------------------------------------------------
@app.route("/get_config")
def get_config():
    try:
        with open(CONFIG_FILE, "r") as f:
            data = json.load(f)
        return jsonify(data)
    except Exception as e:
        return jsonify({"error": str(e)})


@app.route("/save_config", methods=["POST"])
def save_config():
    try:
        new_config = request.get_json()
        if not new_config:
            return jsonify({"success": False, "message": "No config provided"})
        with open(CONFIG_FILE, "w") as f:
            json.dump(new_config, f, indent=4)
        subprocess.run(["sudo", "systemctl", "restart", "face-recognition.service"])
        return jsonify({"success": True, "message": "Configuration saved & service restarted"})
    except Exception as e:
        return jsonify({"success": False, "message": f"Error saving config: {str(e)}"})


# ------------------------------------------------------------
# Entrypoint
# ------------------------------------------------------------
if __name__ == "__main__":
    print("=" * 60)
    print("Face Recognition Manager UI")
    print("=" * 60)
    print(f"Known faces dir: {KNOWN_FACES_DIR}")
    print(f"Encodings file: {ENCODINGS_FILE}")
    print(f"Config file: {CONFIG_FILE}")
    print("=" * 60)
    print("Starting Flask web server (local mode)...")
    app.run(debug=True, host="0.0.0.0", port=5000)
