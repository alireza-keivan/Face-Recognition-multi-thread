#!/usr/bin/env python3
"""Test script to verify the log rotation folder structure implementation"""

import os
from datetime import datetime

# Test the folder structure function
def test_get_date_based_folder():
    LOG_SAVE_DIR = "/home/face/Face-Recognition-multi-thread/saved_faces"
    
    now = datetime.now()
    year = now.strftime("%Y")
    month = now.strftime("%B")  # Full month name (e.g., December)
    day = now.strftime("%d")    # Day with leading zero (01-31)
    
    relative_path = os.path.join(year, month, day)
    full_path = os.path.join(LOG_SAVE_DIR, relative_path)
    
    print("=" * 60)
    print("LOG ROTATION TEST")
    print("=" * 60)
    print(f"Base directory: {LOG_SAVE_DIR}")
    print(f"Year:           {year}")
    print(f"Month:          {month}")
    print(f"Day:            {day}")
    print(f"Relative path:  {relative_path}")
    print(f"Full path:      {full_path}")
    print(f"Exists:         {os.path.exists(full_path)}")
    
    # Test filename format
    safe_name = "TestPerson"
    timestamp = now.strftime("%Y-%m-%d-%H-%M-%S")
    filename = f"{safe_name}-{timestamp}.jpg"
    relative_filename = os.path.join(relative_path, filename)
    
    print("\n" + "=" * 60)
    print("FILENAME FORMAT TEST")
    print("=" * 60)
    print(f"Person name:         {safe_name}")
    print(f"Timestamp:           {timestamp}")
    print(f"Filename:            {filename}")
    print(f"Relative filename:   {relative_filename}")
    print(f"Full file path:      {os.path.join(full_path, filename)}")
    
    # Test with "unknown"
    safe_name = "unknown"
    timestamp = now.strftime("%Y-%m-%d-%H-%M-%S")
    filename = f"{safe_name}-{timestamp}.jpg"
    relative_filename = os.path.join(relative_path, filename)
    
    print("\n" + "=" * 60)
    print("UNKNOWN PERSON TEST")
    print("=" * 60)
    print(f"Person name:         {safe_name}")
    print(f"Filename:            {filename}")
    print(f"Relative filename:   {relative_filename}")
    
    print("\n" + "=" * 60)
    print("✅ All tests completed successfully!")
    print("=" * 60)

if __name__ == "__main__":
    test_get_date_based_folder()
